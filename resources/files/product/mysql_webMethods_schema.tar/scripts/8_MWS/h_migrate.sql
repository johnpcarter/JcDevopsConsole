ALTER TABLE TBLSOCIALENDORSEMENTS MODIFY COLUMN ENDORSE_COUNT NUMERIC(30,2);

DROP PROCEDURE IF EXISTS Alter_TBLUSER_UUID; 


DELIMITER //
CREATE PROCEDURE Alter_TBLUSER_UUID() 
BEGIN 
    DECLARE _count INT; 
    SET _count = ( SELECT count(*)  FROM information_schema.columns 
		   WHERE table_schema = database() AND COLUMN_NAME = 'UUID' AND table_name = 'TBLUSER' ); 
    IF _count = 0 THEN 
       SET @sql= 'alter table TBLUSER add column UUID varchar(128) NULL'; 
PREPARE stmt FROM @sql; 
EXECUTE stmt; 
    END IF; 
END//


DELIMITER ;
CALL Alter_TBLUSER_UUID();

