
CREATE INDEX idx_BDocUKeys_DocId ON BizDocUniqueKeys
(
      DocID            ASC
) ;

