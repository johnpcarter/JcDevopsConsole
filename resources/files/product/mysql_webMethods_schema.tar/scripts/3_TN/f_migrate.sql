
ALTER TABLE CertificateData 
	CHANGE COLUMN ExpirationDate ExpirationDate DATETIME NOT NULL DEFAULT 0;

