
CREATE TABLE PartnerContact (
      PartnerID            CHAR(24) NOT NULL,
      ContactID            CHAR(24) NOT NULL      
)ROW_FORMAT=DYNAMIC
;

ALTER TABLE PartnerContact
       ADD  ( CONSTRAINT pk_PtnrCont_PtnrId_ContId 
       PRIMARY KEY (PartnerID, ContactID) );
       
ALTER TABLE PartnerContact
       ADD  ( CONSTRAINT fk_PtnrCont_PtnrId_Ptnr FOREIGN KEY (PartnerID)
                             REFERENCES Partner(PartnerID) ) ;
                             
ALTER TABLE PartnerContact
       ADD  ( CONSTRAINT fk_PtnrCont_ContId_Cont FOREIGN KEY (ContactID)
                             REFERENCES Contact(ContactID) ) ;

INSERT INTO PartnerContact SELECT PartnerID, ContactID FROM Contact;
COMMIT;        


ALTER TABLE Contact DROP FOREIGN KEY fk_Cont_PtnrId_Ptnr;
DROP INDEX idx_Cont_PtnrId ON Contact;
ALTER TABLE Contact DROP COLUMN PartnerID;

CREATE TABLE PartnerAddress (
      PartnerID            CHAR(24) NOT NULL,
      AddressID            CHAR(24) NOT NULL      
)ROW_FORMAT=DYNAMIC
;

ALTER TABLE PartnerAddress
       ADD  ( CONSTRAINT pk_PtnrAddr_PtnrId_AddrId 
       PRIMARY KEY (PartnerID, AddressID) );
       
ALTER TABLE PartnerAddress
       ADD  ( CONSTRAINT fk_PtnrAddr_PtnrId_Ptnr FOREIGN KEY (PartnerID)
                             REFERENCES Partner(PartnerID) ) ;
                             
ALTER TABLE PartnerAddress
       ADD  ( CONSTRAINT fk_PtnrAddr_AddrId_Addr FOREIGN KEY (AddressID)
                             REFERENCES Address(AddressID) ) ;
                             

INSERT INTO PartnerAddress SELECT PartnerID, AddressID FROM Address WHERE PartnerID != 'NULL';
COMMIT;        

ALTER TABLE Address DROP FOREIGN KEY fk_Address_PtnrId_Ptnr;
DROP INDEX idx_Address_PtnrId ON Address;

ALTER TABLE Address DROP COLUMN PartnerID;


CREATE TABLE PartnerDestination (
      PartnerID            CHAR(24) NOT NULL,
      DestinationID        CHAR(24) NOT NULL      
)ROW_FORMAT=DYNAMIC
;

CREATE INDEX idx_PtnrDest_PtnrId ON PartnerDestination
(
       PartnerID                      ASC
) ;

ALTER TABLE PartnerDestination
       ADD  ( CONSTRAINT pk_PtnrDest_PtnrId_DestId 
       PRIMARY KEY (PartnerID, DestinationID) );
       
ALTER TABLE PartnerDestination
       ADD  ( CONSTRAINT fk_PtnrDest_PtnrId_Ptnr FOREIGN KEY (PartnerID)
                             REFERENCES Partner(PartnerID) ) ;
                             
ALTER TABLE PartnerDestination
       ADD  ( CONSTRAINT fk_PtnrDest_DestId_Dest FOREIGN KEY (DestinationID)
                             REFERENCES Destination(DestinationID) ) ;
       

INSERT INTO PartnerDestination SELECT PartnerID, DestinationID FROM Destination;
COMMIT;        

ALTER TABLE Destination DROP FOREIGN KEY fk_Dest_PtnrId_Ptnr;

DROP INDEX idx_Dest_PtnrId ON Destination;
DROP INDEX idx_Dest_PtnrId_Protocol ON Destination;


ALTER TABLE Destination DROP COLUMN PartnerID;

