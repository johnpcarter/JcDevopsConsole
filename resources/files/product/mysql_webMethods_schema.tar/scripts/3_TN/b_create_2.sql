
INSERT INTO Rprt_Resource_Lookup (Rprt_ResLookup_ID, ResourceName, ResourceKey, Value_EN)
VALUES ('101','ROUTINGSTATUS','NEW','NEW');

INSERT INTO Rprt_Resource_Lookup (Rprt_ResLookup_ID, ResourceName, ResourceKey, Value_EN)
VALUES ('102','ROUTINGSTATUS','DONE','DONE');

INSERT INTO Rprt_Resource_Lookup (Rprt_ResLookup_ID, ResourceName, ResourceKey, Value_EN)
VALUES ('103','ROUTINGSTATUS','ABORTED','ABORTED');

INSERT INTO Rprt_Resource_Lookup (Rprt_ResLookup_ID, ResourceName, ResourceKey, Value_EN)
VALUES ('104','ROUTINGSTATUS','DONE W/ ERRORS','DONE W/ ERRORS');


INSERT INTO Rprt_Resource_Lookup (Rprt_ResLookup_ID, ResourceName, ResourceKey, Value_EN)
VALUES ('105','ROUTINGSTATUS','POLLABLE','POLLABLE');

INSERT INTO Rprt_Resource_Lookup (Rprt_ResLookup_ID, ResourceName, ResourceKey, Value_EN)
VALUES ('106','ROUTINGSTATUS','QUEUED','QUEUED');


INSERT INTO Rprt_Resource_Lookup (Rprt_ResLookup_ID, ResourceName, ResourceKey, Value_EN)
VALUES ('107','ROUTINGSTATUS','ACCEPTED','ACCEPTED');


INSERT INTO Rprt_Resource_Lookup (Rprt_ResLookup_ID, ResourceName, ResourceKey, Value_EN)
VALUES ('108','ROUTINGSTATUS','ACCEPTED W/ ERRORS','ACCEPTED W/ ERRORS');


INSERT INTO Rprt_Resource_Lookup (Rprt_ResLookup_ID, ResourceName, ResourceKey, Value_EN)
VALUES ('109','ROUTINGSTATUS','RESUBMITTING','RESUBMITTING');


INSERT INTO Rprt_Resource_Lookup (Rprt_ResLookup_ID, ResourceName, ResourceKey, Value_EN)
VALUES ('110','ROUTINGSTATUS','REPROCESSING','REPROCESSING');


INSERT INTO Rprt_Resource_Lookup (Rprt_ResLookup_ID, ResourceName, ResourceKey, Value_EN)
VALUES ('111','ROUTINGSTATUS','RESUBMITTED','RESUBMITTED');


INSERT INTO Rprt_Resource_Lookup (Rprt_ResLookup_ID, ResourceName, ResourceKey, Value_EN)
VALUES ('112','ROUTINGSTATUS','REPROCESSED','REPROCESSED');


INSERT INTO Rprt_Resource_Lookup (Rprt_ResLookup_ID, ResourceName, ResourceKey, Value_EN)
VALUES ('113','ROUTINGSTATUS','RESUBMITTED AND ABORTED','RESUBMITTED AND ABORTED');


INSERT INTO Rprt_Resource_Lookup (Rprt_ResLookup_ID, ResourceName, ResourceKey, Value_EN)
VALUES ('114','ROUTINGSTATUS','REPROCESSED AND ABORTED','REPROCESSED AND ABORTED');


INSERT INTO Rprt_Resource_Lookup (Rprt_ResLookup_ID, ResourceName, ResourceKey, Value_EN)
VALUES ('115','ROUTINGSTATUS','RESUBMITTED W/ ERROR','RESUBMITTED W/ ERROR');


INSERT INTO Rprt_Resource_Lookup (Rprt_ResLookup_ID, ResourceName, ResourceKey, Value_EN)
VALUES ('116','ROUTINGSTATUS','REPROCESSED W/ ERROR','REPROCESSED W/ ERROR');


INSERT INTO Rprt_Resource_Lookup (Rprt_ResLookup_ID, ResourceName, ResourceKey, Value_EN)
VALUES ('117','ROUTINGSTATUS','NOT ROUTED','NOT ROUTED');

INSERT INTO Rprt_Resource_Lookup (Rprt_ResLookup_ID, ResourceName, ResourceKey, Value_EN)
VALUES ('201','PARTNERSTATUS','Active','Active');

INSERT INTO Rprt_Resource_Lookup (Rprt_ResLookup_ID, ResourceName, ResourceKey, Value_EN)
VALUES ('202','PARTNERSTATUS','Inactive','Inactive');

INSERT INTO Rprt_Resource_Lookup (Rprt_ResLookup_ID, ResourceName, ResourceKey, Value_EN)
VALUES ('301','FASTATUS','100','Not Acknowledged');

INSERT INTO Rprt_Resource_Lookup (Rprt_ResLookup_ID, ResourceName, ResourceKey, Value_EN)
VALUES ('302','FASTATUS','110','Disabled');

INSERT INTO Rprt_Resource_Lookup (Rprt_ResLookup_ID, ResourceName, ResourceKey, Value_EN)
VALUES ('303','FASTATUS','120','Duplicate');

INSERT INTO Rprt_Resource_Lookup (Rprt_ResLookup_ID, ResourceName, ResourceKey, Value_EN)
VALUES ('304','FASTATUS','130','Error');

INSERT INTO Rprt_Resource_Lookup (Rprt_ResLookup_ID, ResourceName, ResourceKey, Value_EN)
VALUES ('305','FASTATUS','140','Duplicate FA');

INSERT INTO Rprt_Resource_Lookup (Rprt_ResLookup_ID, ResourceName, ResourceKey, Value_EN)
VALUES ('306','FASTATUS','150','Accepted');

INSERT INTO Rprt_Resource_Lookup (Rprt_ResLookup_ID, ResourceName, ResourceKey, Value_EN)
VALUES ('307','FASTATUS','160','Accept w/Error');

INSERT INTO Rprt_Resource_Lookup (Rprt_ResLookup_ID, ResourceName, ResourceKey, Value_EN)
VALUES ('308','FASTATUS','170','Accept - Partial');

INSERT INTO Rprt_Resource_Lookup (Rprt_ResLookup_ID, ResourceName, ResourceKey, Value_EN)
VALUES ('309','FASTATUS','180','Rejected');

INSERT INTO Rprt_Resource_Lookup (Rprt_ResLookup_ID, ResourceName, ResourceKey, Value_EN)
VALUES ('310','FASTATUS','190','FA Error');

INSERT INTO Rprt_Resource_Lookup (Rprt_ResLookup_ID, ResourceName, ResourceKey, Value_EN)
VALUES ('311','FASTATUS','195','Any Status');

INSERT INTO Rprt_Resource_Lookup (Rprt_ResLookup_ID, ResourceName, ResourceKey, Value_EN)
VALUES ('401','DIRECTION','0','Inbound');

INSERT INTO Rprt_Resource_Lookup (Rprt_ResLookup_ID, ResourceName, ResourceKey, Value_EN)
VALUES ('402','DIRECTION','1','Outbound');


-- ********************************************************************

COMMIT ;

-- ********************************************************************

