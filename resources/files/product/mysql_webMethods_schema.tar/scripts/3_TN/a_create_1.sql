
CREATE TABLE Partner (
	ParentPartnerID		CHAR(24) NULL,
	PartnerID		CHAR(24) NOT NULL,
	CorporationName		VARCHAR(255) NOT NULL,
	OrgUnitName		VARCHAR(255) NULL,
	Deleted			SMALLINT NOT NULL,
	Status			VARCHAR(12) NOT NULL,
	Substatus		VARCHAR(12) NULL,
	Type			CHAR(12) NOT NULL,
	Self			SMALLINT NOT NULL,
	TNVersion		VARCHAR(20) NULL,
	B2BcomMember		SMALLINT DEFAULT 0 NULL,
	PreferredLocale		VARCHAR(16) NULL,
	RoutingOff		SMALLINT DEFAULT 0 NULL,
	LastModified TIMESTAMP(3) DEFAULT 0 NOT NULL
)ROW_FORMAT=DYNAMIC  
;

CREATE INDEX idx_Ptnr_CorpName_OrgUnitName ON Partner
(
       CorporationName                ASC,
       OrgUnitName                    ASC
);

ALTER TABLE Partner
       ADD  ( CONSTRAINT pk_Ptnr_PtnrId PRIMARY KEY (PartnerID) )
;



CREATE TABLE BizDocAttributeDef (
    AttributeName        VARCHAR(255) NOT NULL,
    AttributeID          CHAR(24) NOT NULL,
    AttributeDescription VARCHAR(1024) NULL,
    AttributeType        VARCHAR(20) NOT NULL,
    Deleted              SMALLINT NOT NULL,
    Persist              SMALLINT,
    BDASystem               SMALLINT DEFAULT 0 NOT NULL ,
    LastModified         TIMESTAMP(3) NULL
)ROW_FORMAT=DYNAMIC   
;

ALTER TABLE BizDocAttributeDef
      ADD  ( CONSTRAINT pk_BizDocAttDef_AttId PRIMARY KEY (AttributeID) )
;



CREATE TABLE BizDocTypeDef (
      TypeName             VARCHAR(128) NOT NULL,
      TypeID               CHAR(24) NOT NULL,
      TypeDescription      VARCHAR(255) NULL,
      TypeData             BLOB NOT NULL,
      Deleted              SMALLINT NOT NULL,
      LastModified         TIMESTAMP(3) NULL,
      SubTypeID		       SMALLINT NULL ,
      BDType                 SMALLINT DEFAULT 0 NOT NULL
)ROW_FORMAT=DYNAMIC
;

ALTER TABLE BizDocTypeDef
       ADD  ( CONSTRAINT pk_BizDocTypeDef_TypeId PRIMARY KEY (TypeID)   )
;



CREATE TABLE BinaryType (
      Type                 SMALLINT NOT NULL,
      Description          VARCHAR(255) NOT NULL
)
;

ALTER TABLE BinaryType
      ADD  ( CONSTRAINT pk_BinaryType_Type PRIMARY KEY (Type)   )
;


CREATE TABLE ContactType (
      Type                 SMALLINT NOT NULL,
      Description          VARCHAR(128) NOT NULL
)
;

ALTER TABLE ContactType
       ADD  ( CONSTRAINT pk_ContType_Type PRIMARY KEY (Type)   )
;


CREATE TABLE BizDoc (
      DocID                CHAR(24) NOT NULL,
      DocTypeID            CHAR(24) NULL,
      SenderID             CHAR(24) NOT NULL,
      ReceiverID           CHAR(24) NOT NULL,
      NativeID             VARCHAR(256) NULL,
      DocTimestamp         TIMESTAMP(3) NOT NULL DEFAULT 0,
      RoutingStatus        VARCHAR(30) NOT NULL,
      GroupID              VARCHAR(100) NULL,
      ConversationID       VARCHAR(300) NULL,
      UserStatus           VARCHAR(255) NULL,
      ReceiveSvc           VARCHAR(250) NULL,
      OrigSenderID         VARCHAR(140) NULL,
      OrigReceiverID       VARCHAR(140) NULL,
      LastModified         TIMESTAMP(3) NULL,
      Comments             VARCHAR(250) NULL,
      RepeatNum            SMALLINT DEFAULT 0 NULL,
      Date_Dim_ID          INTEGER(10),
      Time_Dim_ID          INTEGER
)ROW_FORMAT=DYNAMIC
;

CREATE INDEX idx_BizDoc_DocTypeId ON BizDoc
(
      DocTypeID            ASC
) ;

CREATE INDEX idx_BizDoc_SenderId ON BizDoc
(
      SenderID             ASC
) ;

CREATE INDEX idx_BizDoc_ReceiverId ON BizDoc
(
      ReceiverID           ASC
) ;

CREATE INDEX idx_BizDoc_Dtstamp ON BizDoc 
(
      DocTimestamp	DESC
) ;

CREATE INDEX idx_BizDoc_Nativeid ON BizDoc 
(
      NativeID
) ;

CREATE INDEX idx_BizDoc_Groupid ON BizDoc 
(
      GroupID
) ;

ALTER TABLE BizDoc
      ADD  ( CONSTRAINT pk_BizDoc_DocId PRIMARY KEY (DocID)   )
;

ALTER TABLE BizDoc
       ADD  ( CONSTRAINT fk_BizDoc_ReceiverId_Ptnr FOREIGN KEY (ReceiverID)
                             REFERENCES Partner(PartnerID) ) ;

ALTER TABLE BizDoc
       ADD  ( CONSTRAINT fk_BizDoc_SenderId_Ptnr FOREIGN KEY (SenderID)
                             REFERENCES Partner(PartnerID) ) ;

ALTER TABLE BizDoc
       ADD  ( CONSTRAINT fk_BizDoc_DocTyId_BizDocTypDef FOREIGN KEY (DocTypeID)
                             REFERENCES BizDocTypeDef(TypeID) ) ;



CREATE TABLE BizDocAttribute (
      DocID                CHAR(24) NOT NULL,
      AttributeID          CHAR(24) NOT NULL,
      StringValue          VARCHAR(512) NULL,
      NumberValue          DOUBLE NULL,
      DateValue            TIMESTAMP(3) NULL
)ROW_FORMAT=DYNAMIC
   
   
;

CREATE INDEX idx_BizDocAtt_AttId ON BizDocAttribute
(
      AttributeID          ASC
) ;

ALTER TABLE BizDocAttribute
      ADD  ( CONSTRAINT pk_BizDocAtt_DocId_AttId PRIMARY KEY (DocID, AttributeID)   )
;


ALTER TABLE BizDocAttribute
       ADD  ( CONSTRAINT fk_BizDocAtt_DocId_BizDoc FOREIGN KEY (DocID)
                             REFERENCES BizDoc(DocID) ) ;

ALTER TABLE BizDocAttribute
       ADD  ( CONSTRAINT fk_BizDocAtt_AttId_BizDocAtDef FOREIGN KEY (AttributeID)
                             REFERENCES BizDocAttributeDef(AttributeID) ) ;



CREATE TABLE BizDocArrayAttribute (
      DocID                CHAR(24) NOT NULL,
      AttributeID          CHAR(24) NOT NULL,
      SeqNumber		   INTEGER NOT NULL,
      StringValue          VARCHAR(512) NULL,
      NumberValue          DOUBLE NULL,
      DateValue            TIMESTAMP(3) NULL
)ROW_FORMAT=DYNAMIC
   
   
;

CREATE INDEX idx_BDArrAtt_AttId ON BizDocArrayAttribute
(
      AttributeID          ASC
) ;

ALTER TABLE BizDocArrayAttribute
      ADD ( CONSTRAINT pk_BDArrAtt_DocId_AttId PRIMARY KEY (DocID, AttributeID, SeqNumber)   )
;

ALTER TABLE BizDocArrayAttribute
       ADD CONSTRAINT fk_BDArrAtt_DocId_BizDoc FOREIGN KEY (DocID)
                             REFERENCES BizDoc(DocID) ;

ALTER TABLE BizDocArrayAttribute
       ADD CONSTRAINT fk_BDArrAtt_AttId_BizDocAtDef FOREIGN KEY (AttributeID)
                             REFERENCES BizDocAttributeDef(AttributeID) ;



CREATE TABLE BizDocBAMAttribute 
(
	TypeID              CHAR(24)         NOT NULL,  
	AttributeID    	    VARCHAR(255)    NOT NULL,  
	AttributeName       VARCHAR(255) 
)ROW_FORMAT=DYNAMIC
   
   
;

ALTER TABLE BizDocBAMAttribute
      ADD ( CONSTRAINT pk_BDBAMAtt_TypeId_AttId PRIMARY KEY (TypeID, AttributeID)   )
;

ALTER TABLE BizDocBAMAttribute
       ADD CONSTRAINT fk_BDBAMAtt_TypeId_BDTypeDef FOREIGN KEY (TypeID)
                             REFERENCES BizDocTypeDef (TypeID);



CREATE TABLE BizDocContent (
      DocID                CHAR(24) NOT NULL,
      PartName		   VARCHAR(100) NOT NULL,
      MimeType		   VARCHAR(256),
      ContentLength	   INTEGER NULL,
      Content	         LONGBLOB NULL,
      PartIndex	           INTEGER NULL,
      StorageType       VARCHAR(100) NULL,
      StorageRef        VARCHAR(250) NULL
)ROW_FORMAT=DYNAMIC
   
   
   
;

ALTER TABLE BizDocContent
       ADD ( CONSTRAINT pk_BizDocCont_DocId_PartName PRIMARY KEY (DocID,PartName)   )
;

ALTER TABLE BizDocContent
       ADD  ( CONSTRAINT fk_BizDocCont_DocId_BizDoc FOREIGN KEY (DocID)
                             REFERENCES BizDoc (DocID)) ;



CREATE TABLE BizDocRelationship (
       DocID                CHAR(24) NOT NULL,
       RelatedDocID         CHAR(24) NOT NULL,
       Relationship         VARCHAR(255) NULL
)ROW_FORMAT=DYNAMIC
   
   
;

CREATE INDEX idx_BizDocRel_RelatedDocId ON BizDocRelationship
(
      RelatedDocID                   ASC
) ;

ALTER TABLE BizDocRelationship
       ADD  ( CONSTRAINT pk_BizDocRel_DocId_RelatDocId PRIMARY KEY (DocID, RelatedDocID)   )
;




CREATE TABLE BizDocTypeAttribute (
      AttributeID          CHAR(24) NOT NULL,
      TypeID               CHAR(24) NOT NULL
)ROW_FORMAT=DYNAMIC
   
   
;

CREATE INDEX idx_BizDocTypeAtt_TypeId ON BizDocTypeAttribute
(
      TypeID                         ASC
) ;

ALTER TABLE BizDocTypeAttribute
       ADD  ( CONSTRAINT pk_BizDocTypeAtt_AttId_TypeId PRIMARY KEY (AttributeID, TypeID)   )
;

ALTER TABLE BizDocTypeAttribute
       ADD  ( CONSTRAINT fk_BDocTypAtt_TypId_BDocTypDef FOREIGN KEY (TypeID)
                             REFERENCES BizDocTypeDef (TypeID)) ;

ALTER TABLE BizDocTypeAttribute
       ADD  ( CONSTRAINT fk_BDocTypAtt_AttId_BDocAttDef FOREIGN KEY (AttributeID)
                             REFERENCES BizDocAttributeDef(AttributeID) ) ;



CREATE TABLE Contact (
      ContactID            CHAR(24) NOT NULL,
      PartnerID            CHAR(24) NOT NULL,
      Surname              VARCHAR(255) NULL,
      GivenName            VARCHAR(255) NULL,
      SequenceNumber       SMALLINT NOT NULL,
      RoleDescription		VARCHAR(128) NULL,
      Type                 SMALLINT NOT NULL,
      EmailAddress         VARCHAR(255) NULL,
      TelNumber            VARCHAR(60) NULL,
      TelExtension         VARCHAR(60) NULL,
      FaxNumber            VARCHAR(60) NULL,
      PagerNumber          VARCHAR(60) NULL
)ROW_FORMAT=DYNAMIC
   
   
;

CREATE INDEX idx_Cont_PtnrId ON Contact
(
       PartnerID                      ASC
) ;

ALTER TABLE Contact
       ADD  ( CONSTRAINT pk_Cont_ContId PRIMARY KEY ( ContactID)   )
;

ALTER TABLE Contact
       ADD  ( CONSTRAINT fk_Cont_PtnrId_Ptnr FOREIGN KEY (PartnerID)
                             REFERENCES Partner(PartnerID)) ;

ALTER TABLE Contact
  ADD CONSTRAINT fk_Contact_Type_ContType
      FOREIGN KEY(Type) REFERENCES ContactType(Type) ;

CREATE TABLE Address (
      AddressID            CHAR(24) NOT NULL,
      PartnerID            CHAR(24) NULL,
      ContactID            CHAR(24) NULL,
      AddressLine1         VARCHAR(255) NULL,
      AddressLine2         VARCHAR(255) NULL,
      AddressLine3         VARCHAR(255) NULL,
      City                 VARCHAR(255) NULL,
      State_Province       VARCHAR(128) NULL,
      Zip_PostalCode       VARCHAR(128) NULL,
      Country              VARCHAR(60) NULL,
      SequenceNumber       SMALLINT NULL
)ROW_FORMAT=DYNAMIC
   
   
;

CREATE INDEX idx_Address_ContId ON Address
(
      ContactID            ASC
) ;

CREATE INDEX idx_Address_PtnrId ON Address
(
      PartnerID            ASC
) ;

ALTER TABLE Address
      ADD  ( CONSTRAINT pk_Address_AddressId PRIMARY KEY (AddressID)   )
;

ALTER TABLE Address
       ADD  ( CONSTRAINT fk_Address_PtnrId_Ptnr FOREIGN KEY (PartnerID)
                             REFERENCES Partner(PartnerID)) ;

ALTER TABLE Address
       ADD CONSTRAINT fk_Address_ContId_Cont FOREIGN KEY (ContactID)
                            REFERENCES Contact(ContactID) ;



CREATE TABLE DeliveryService (
      ServiceName          VARCHAR(128) NOT NULL,
      B2BInterface         VARCHAR(512) NOT NULL,
      B2BService           VARCHAR(512) NOT NULL,
      RemoteLocation       VARCHAR(128) NULL,
      RemoteUser           VARCHAR(32) NULL,
      RemotePassword       VARCHAR(32) NULL,
      Scheduled            INTEGER
)ROW_FORMAT=DYNAMIC
   
   
;

ALTER TABLE DeliveryService
       ADD  ( CONSTRAINT pk_DeliServ_ServName PRIMARY KEY (ServiceName)   )
;



CREATE TABLE DeliveryJob (
      JobID                CHAR(24) NOT NULL,
      ServerID             VARCHAR(50) NOT NULL,
      TimeCreated          TIMESTAMP(3) NULL,
      TimeUpdated          TIMESTAMP(3) NULL,
      JobStatus            VARCHAR(20) NULL,
      TimeToWait           INTEGER NULL,
      Retries              INTEGER NULL,
      RetryLimit           INTEGER NULL,
      TransportStatus      VARCHAR(60) NULL,
      TransportStatusMessage VARCHAR(512) NULL,
      TransportTime        INTEGER NULL,
      DocID                CHAR(24) NULL,
      OutputData           BLOB NULL,
      ServiceName          VARCHAR(128) NULL,
      RetryFactor	   INTEGER NULL,
      TypeData		   BLOB NULL,
      JobType		   VARCHAR(20) NULL,
      QueueName        VARCHAR(254) NULL,
      UserName         VARCHAR(254) NULL
)ROW_FORMAT=DYNAMIC
   
   
   
;

CREATE INDEX idx_DeliJob_ServName ON DeliveryJob
(
       ServiceName                    ASC
) ;

CREATE INDEX idx_DeliJob_DocId ON DeliveryJob
(
       DocID                          ASC
) ;

CREATE INDEX idx_DeliJob_ServerId ON DeliveryJob
(
       ServerID                       ASC
) ;

CREATE INDEX idx_DeliJob_QueName ON DeliveryJob
(
       QueueName                      ASC,
       JobStatus			 ,
       TimeUpdated
) ;

CREATE INDEX idx_DJob_TimeCreat ON DeliveryJob 
(
       TimeCreated                   DESC
) ;

ALTER TABLE DeliveryJob
       ADD  ( CONSTRAINT pk_DeliJob_JobId PRIMARY KEY (JobID)   )
;



CREATE TABLE Destination (
       DestinationID        CHAR(24) NOT NULL,
       PartnerID            CHAR(24) NOT NULL,
       Protocol             VARCHAR(64) NOT NULL,
       Host                 VARCHAR(64) NULL,
       PrimaryAddr          INTEGER NOT NULL,
       Port                 VARCHAR(6) NULL,
       Location             VARCHAR(255) NULL,
       UserName             VARCHAR(100) NULL,
       Password             VARCHAR(24) NULL,
       CustomData	    BLOB NULL
)ROW_FORMAT=DYNAMIC
   
   
   
;

CREATE INDEX idx_Dest_PtnrId ON Destination
(
       PartnerID                      ASC
) ;

CREATE INDEX idx_Dest_PtnrId_Protocol ON Destination
(
       PartnerID,
       Protocol
) ;

ALTER TABLE Destination
       ADD ( CONSTRAINT pk_Dest_DestinationId PRIMARY KEY (DestinationID)   )
;

ALTER TABLE Destination
       ADD  ( CONSTRAINT fk_Dest_PtnrId_Ptnr FOREIGN KEY (PartnerID)
                             REFERENCES Partner(PartnerID)) ;



CREATE TABLE IDType (
       Type                 INTEGER NOT NULL,
       Description          VARCHAR(255) NOT NULL
)
   
   
;

ALTER TABLE IDType
       ADD  ( CONSTRAINT pk_IdType_Type PRIMARY KEY (Type)   )
;



CREATE TABLE PartnerBinary (
       PartnerID            CHAR(24) NOT NULL,
       Type                 VARCHAR(20) NOT NULL,
       Value                BLOB NULL
)ROW_FORMAT=DYNAMIC
   
   
   
;

CREATE INDEX idx_PtnrBin_PtnrId ON PartnerBinary
(
       PartnerID                      ASC
) ;

ALTER TABLE PartnerBinary
       ADD  ( CONSTRAINT pk_PtnrBin_PtnrId_Type PRIMARY KEY (PartnerID, Type)   )
;

ALTER TABLE PartnerBinary
       ADD  ( CONSTRAINT fk_PtnrBin_PtnrId_Ptnr FOREIGN KEY (PartnerID)
                             REFERENCES Partner(PartnerID)) ;



CREATE TABLE PartnerID (
       PartnerIDID          CHAR(24) NOT NULL,
       InternalID           CHAR(24) NOT NULL,
       ExternalID           VARCHAR(140) NOT NULL,
       IDType               INTEGER NOT NULL,
       SequenceNumber       SMALLINT NOT NULL
)ROW_FORMAT=DYNAMIC
   
   
;

CREATE INDEX idx_PtnrIdTbl_InternalId ON PartnerID
(
       InternalID                     ASC
) ;

CREATE INDEX idx_PtnrIdTbl_IDType ON PartnerID
(
       IDType                         ASC
) ;

ALTER TABLE PartnerID
       ADD ( CONSTRAINT pk_PtnrIdTbl_PtnrIdId PRIMARY KEY (PartnerIDID)   )
;

ALTER TABLE PartnerID
       ADD  ( CONSTRAINT fk_PtnrIdTbl_InternalId_Ptnr FOREIGN KEY (InternalID)
                             REFERENCES Partner(PartnerID)) ;

CREATE TABLE FieldGroup (
       ID           smallint     NOT NULL,
       Description  varchar(128) NOT NULL
)ROW_FORMAT=DYNAMIC
   
   
;

ALTER TABLE FieldGroup
       ADD CONSTRAINT pk_GroupID_ID PRIMARY KEY (ID) 
	    
;



CREATE TABLE ProfileField (
       ProfileFieldID       CHAR(24) NOT NULL,
       Name                 VARCHAR(255) NULL,
       Required             SMALLINT NOT NULL,
       Registration         SMALLINT NOT NULL,
       ValidValues          VARCHAR(4000) NULL,
       DefaultValue         VARCHAR(128) NULL,
       ProfileTbl           VARCHAR(20) NULL,
       DataType             VARCHAR(10) NULL,
       ProfileCol           VARCHAR(20) NULL,
       Deleted              SMALLINT NOT NULL,
       GroupID              SMALLINT NOT NULL,
       Description          VARCHAR(1024) NULL,
       MaxLength            INTEGER NULL,
       Display              SMALLINT NOT NULL
)ROW_FORMAT=DYNAMIC
    ;

CREATE INDEX idx_ProfFld_ProfTbl_ProfCol ON ProfileField
(
       ProfileTbl                     ASC,
       ProfileCol                     ASC
) ;

CREATE INDEX idx_ProfFld_Name ON ProfileField
(
       Name                           ASC
) ;

CREATE INDEX idx_ProfFld_GroupId ON ProfileField
(
       GroupID                        ASC
) ;

ALTER TABLE ProfileField
       ADD  ( CONSTRAINT pk_ProfFld_ProfFldId PRIMARY KEY (ProfileFieldID)   )
;

ALTER TABLE ProfileField
	ADD CONSTRAINT fk_ProfileFld_GrpID_FieldGrp FOREIGN KEY (GroupID)
			   REFERENCES FieldGroup(ID) ;



CREATE TABLE PartnerProfileField (
       ProfileFieldID       CHAR(24) NOT NULL,
       ValueBinary          BLOB NULL,
       PartnerID            CHAR(24) NOT NULL,
       ValueString          VARCHAR(4000) NULL,
	 ProfileFieldName	    VARCHAR(256) NULL
)ROW_FORMAT=DYNAMIC
    ;

CREATE INDEX idx_PtnrProFld_ProFldId ON PartnerProfileField
(
       ProfileFieldID                 ASC
) ;

CREATE INDEX idx_PtnrProFld_PtnrId ON PartnerProfileField
(
       PartnerID                      ASC
) ;

ALTER TABLE PartnerProfileField
       ADD  ( CONSTRAINT pk_PtnrProFld_PtnrId_ProFldId PRIMARY KEY (PartnerID, ProfileFieldID)   )
;

ALTER TABLE PartnerProfileField
       ADD  ( CONSTRAINT fk_PtnrProFld_ProFldId_ProFld FOREIGN KEY (ProfileFieldID)
                             REFERENCES ProfileField (ProfileFieldID)) ;

ALTER TABLE PartnerProfileField
       ADD  ( CONSTRAINT fk_PtnrProFld_PtnrId_Ptnr FOREIGN KEY (PartnerID)
                             REFERENCES Partner(PartnerID)) ;



CREATE TABLE ProcessingRule (
	RuleID			CHAR(24) NOT NULL,
	RuleIndex			INTEGER NOT NULL,
	RuleDescription		VARCHAR(255) NULL,
	RuleName			VARCHAR(128) NOT NULL,
	RuleData			BLOB NULL,
	LastModified		TIMESTAMP(3) NULL,
	Disabled			SMALLINT NOT NULL,
	LastChangeID		CHAR(24) NULL,
	LastChangeUser		VARCHAR(255) NULL,
	LastChangeSession		VARCHAR(255) NULL
)ROW_FORMAT=DYNAMIC
   
   
   
;

ALTER TABLE ProcessingRule
	ADD ( CONSTRAINT pk_ProcessingRule_RuleID PRIMARY KEY (RuleID)   )
;



CREATE TABLE ProcessingRuleModification (
	LastChangeID		CHAR(24) NOT NULL,
	LastChangeUser		VARCHAR(255) NULL,
	LastChangeSession		VARCHAR(255) NULL
)ROW_FORMAT=DYNAMIC
    ;

ALTER TABLE ProcessingRuleModification
	ADD CONSTRAINT pk_ProcessingRuleMod_ChangeID PRIMARY KEY (LastChangeID)
	 
;



CREATE TABLE Remote (
       PartnerID            CHAR(24) NOT NULL,
       Certificate          VARCHAR(255) NULL,
       CACertificate        VARCHAR(255) NULL,
       RemoteStatus         VARCHAR(12) NULL,
       PrivateKey           VARCHAR(255) NULL,
       PreferredProtocol    VARCHAR(128) NULL,
       PollingFrequency     DOUBLE NULL,
       DeliveryMaxRetries   SMALLINT NULL,
       DeliveryRetryWait    INTEGER NULL,
       PollingProtocol      VARCHAR(128) NULL,
       RetryFactor	    INTEGER NULL,
       DeliveryQueue    VARCHAR(254) NULL
)ROW_FORMAT=DYNAMIC
   
   
;

ALTER TABLE Remote
       ADD  ( CONSTRAINT pk_Remote_PtnrId PRIMARY KEY (PartnerID)   )
;

ALTER TABLE Remote
       ADD  ( CONSTRAINT fk_Remote_PtnrId_Ptnr FOREIGN KEY (PartnerID)
                             REFERENCES Partner(PartnerID)) ;



CREATE TABLE ActivityLog (
       ActivityLogID		char(24) NOT NULL,
       RelatedDocID         	char(24),
       RelatedDocTypeID         char(24),
       EntryTimestamp       	timestamp(3) NOT NULL DEFAULT 0,
       EntryType            	int NOT NULL,
       EntryClass          	varchar(30),
       BriefMessage        	varchar(240) NOT NULL,
       RelatedPartnerID     	char(24),
       RelatedInstanceID	varchar(300),
       RelatedProcRuleID     	char(24),
       RelatedStepID		varchar(128),
       B2BUser              	varchar(128),
       FullMessage          	varchar(1024)
)ROW_FORMAT=DYNAMIC
   
   
;

CREATE INDEX idx_ActLog_RelatedDocId ON ActivityLog
(
       RelatedDocID
) ;

CREATE INDEX idx_ActLog_RelatedPtnrId ON ActivityLog
(
       RelatedPartnerID
) ;

CREATE INDEX idx_ActLog_RelatedDTypId ON ActivityLog
(
       RelatedDocTypeID
) ;

CREATE INDEX idx_ActLog_RelatedPRId ON ActivityLog
(
       RelatedProcRuleID
) ;

CREATE INDEX idx_ALog_ETstamp ON ActivityLog 
(
       EntryTimestamp		DESC
) ;

ALTER TABLE ActivityLog
       ADD ( CONSTRAINT pk_ActivityLog PRIMARY KEY (ActivityLogID)   )
;
       
ALTER TABLE ActivityLog
       ADD CONSTRAINT fk_ActLog_RelatedPtnrId_Ptnr FOREIGN KEY (RelatedPartnerID)
                             REFERENCES Partner(PartnerID);

ALTER TABLE ActivityLog
       ADD CONSTRAINT fk_ActLog_RelatedDocId_BizDoc FOREIGN KEY (RelatedDocID)
                             REFERENCES BizDoc(DocID);

ALTER TABLE ActivityLog
       ADD CONSTRAINT fk_ActLog_RelatedDocId_BDTD FOREIGN KEY (RelatedDocTypeID)
                             REFERENCES BizDocTypeDef(TypeID);




CREATE TABLE DeliveryQueue (
	QueueName            VARCHAR(254) NOT NULL,
	QueueType            VARCHAR(12) NOT NULL,
	QueueState           VARCHAR(12) NOT NULL,
	Schedule             BLOB NOT NULL
)ROW_FORMAT=DYNAMIC
    ;

CREATE INDEX idx_DeliQueue_QueueType ON DeliveryQueue
(
  QueueType
) ;

ALTER TABLE DeliveryQueue
       ADD ( CONSTRAINT pk_DeliQueue_QueueName PRIMARY KEY (QueueName)   )
;



CREATE TABLE CertificateData
(
	CertID					CHAR(24) NOT NULL,
	OwnerID					CHAR(24) NOT NULL,
	PartnerID				CHAR(24) NULL,
	`Usage`					VARCHAR(20) NOT NULL,
	CertificateData			BLOB NULL,
	ExpirationDate			TIMESTAMP(3) NOT NULL DEFAULT 0,
	KeystoreAlias			VARCHAR(250) NULL,
	KeyAlias				VARCHAR(250) NULL,
	Priority				SMALLINT NOT NULL
)ROW_FORMAT=DYNAMIC
    ;

CREATE INDEX Idx_CertData_Ownr ON CertificateData( OwnerID )  ;

CREATE INDEX Idx_CertData_Ptnr ON CertificateData( PartnerID )  ;

ALTER TABLE CertificateData 
ADD ( CONSTRAINT pk_CertData_CertID	PRIMARY KEY ( CertID )   )
;

ALTER TABLE CertificateData ADD CONSTRAINT fk_CertData_OwnrID_Ptnr
	FOREIGN KEY ( OwnerID ) REFERENCES Partner( PartnerID );

ALTER TABLE CertificateData ADD CONSTRAINT fk_CertData_PtnrID_Ptnr
	FOREIGN KEY ( PartnerID ) REFERENCES Partner( PartnerID );



CREATE TABLE ProfileGroup (
		GroupID			CHAR(24) NOT NULL,
		GroupName		VARCHAR(200) NULL,
		Description		VARCHAR(450) NULL
)ROW_FORMAT=DYNAMIC
    ;

ALTER TABLE ProfileGroup
		ADD ( CONSTRAINT pk_PGroup_GroupID PRIMARY KEY (GroupID)   )
;



CREATE TABLE PartnerProfileGroup(
		PartnerID			CHAR(24) NOT NULL,
		GroupID			CHAR(24) NOT NULL
)ROW_FORMAT=DYNAMIC 
    ;

CREATE INDEX idx_PtnrPGrp_PtnID on PartnerProfileGroup
(
		PartnerID			ASC
) ;

CREATE INDEX idx_PtnrPGrp_GrpID on PartnerProfileGroup
(
		GroupID				ASC
) ;

ALTER TABLE PartnerProfileGroup
		ADD ( CONSTRAINT pk_PPGrp_PID_GrpID PRIMARY KEY (PartnerID, GroupID)   )
;

ALTER TABLE PartnerProfileGroup
		ADD CONSTRAINT fk_PPGrp_PID_Ptnr 
				FOREIGN KEY (PartnerID) REFERENCES Partner(PartnerID) ;

ALTER TABLE PartnerProfileGroup
		ADD CONSTRAINT fk_PPGrp_GpID_PGrp
				FOREIGN KEY (GroupID) REFERENCES ProfileGroup(GroupID);



CREATE TABLE PartnerUser (
	PartnerID	char(24) NOT NULL,
	UserName	varchar(128) NOT NULL,
	TNCreated	smallint NOT NULL,
	DateCreated	timestamp(3) 
)ROW_FORMAT=DYNAMIC
    ;

CREATE INDEX idx_PtnUsr_PtnID ON PartnerUser
(
	PartnerID	ASC
) ;

ALTER TABLE PartnerUser ADD ( Constraint pk_PartnerUser PRIMARY KEY(PartnerID, UserName)   )
;

ALTER TABLE PartnerUser ADD Constraint fk_PtnrUser_PtnrID FOREIGN KEY(PartnerID) REFERENCES Partner(PartnerID) ;



CREATE TABLE TPA (
       TpaID            char(24) NOT NULL,
       Description      varchar(1024) NULL,
       SenderID         char(24) NULL,
       ReceiverID       char(24) NULL,
       AgreementID      varchar(254) NOT NULL,
       TimeCreated      timestamp(3) NULL,
       LastModified     timestamp(3) NULL,
       ControlNumber    int NULL,
       Status           varchar(20) NULL,
       ExportService    varchar(254) NULL,
       InitService      varchar(254) NULL,
       ValidationSvc    varchar(254) NULL,
       DataSchema       varchar(254) NULL,
       DataStatus       varchar(24) NULL,
       TpaData          BLOB NULL,
       Version          varchar(20) NULL
)ROW_FORMAT=DYNAMIC
    ;

CREATE INDEX idx_TPA_SenderId ON TPA
(
       SenderID
) ;

CREATE INDEX idx_TPA_ReceiverId ON TPA
(
       ReceiverID
) ;

CREATE INDEX idx_TPA_AgreementId ON TPA
(
       AgreementID
) ;

ALTER TABLE TPA
       ADD ( CONSTRAINT pk_TPA_TpaId PRIMARY KEY (TpaID)   )
 ;



CREATE TABLE TPALock (
       LockID            char(24) NOT NULL,
       Description      varchar(1024) NULL,
       TimeExpired      timestamp(3) NULL
)ROW_FORMAT=DYNAMIC
    ;

ALTER TABLE TPALock
       ADD CONSTRAINT pk_TPALock_LockId PRIMARY KEY (LockID)
	    
 ;



CREATE TABLE TNStatistics (
	ServerID             varchar(255) NOT NULL,
	StatisticsType       varchar(64) NOT NULL,
	StatisticsData       blob 
)ROW_FORMAT=DYNAMIC
    ;



CREATE TABLE BizDocUniqueKeys (
		DocID           char(24) NOT NULL,
		UniqueKey       varchar(254) NOT NULL
)ROW_FORMAT=DYNAMIC
    ;

ALTER TABLE BizDocUniqueKeys
	ADD CONSTRAINT pk_BDUniq_UniqKey PRIMARY KEY (UniqueKey) 
	 
 ;



CREATE TABLE TNModelVersion (
       MajorVersion         INTEGER NOT NULL,
       MinorVersion         INTEGER NOT NULL
)ROW_FORMAT=DYNAMIC
    ;

ALTER TABLE TNModelVersion
       ADD  ( CONSTRAINT pk_TNModelVer_MajVer_MinorVer PRIMARY KEY (MajorVersion, MinorVersion)   )
 ;



CREATE TABLE EDITracking (
       DocID                char(24) NOT NULL,
       DocTypeID            char(24) NOT NULL,
       SenderID             char(24) NOT NULL,
       ReceiverID           char(24) NOT NULL,
       EnvelopeID           varchar(100),
       GroupID		    varchar(100),
       TransactionSetID     varchar(100),
       GroupType 	    varchar(100),
       GroupVersion	    varchar(100),
       DocTimestamp         timestamp(3) NOT NULL DEFAULT 0,
       FATimestamp          timestamp(3),
       FAStatus             integer NOT NULL,
       RelatedDocID	    char(24)
)ROW_FORMAT=DYNAMIC
   
   
;

CREATE INDEX idx_EDITracking_SenderID ON EDITracking
(
       SenderID
) ;

CREATE INDEX idx_EDITracking_ReceiverID ON EDITracking
(
       ReceiverID
) ;

CREATE INDEX idx_EDITracking_GroupID ON EDITracking
(
       GroupID
) ;

CREATE INDEX idx_EDITracking_DocTimestamp ON EDITracking
(
       DocTimestamp
) ;

CREATE INDEX idx_EDITracking_FAStatus ON EDITracking
(
       FAStatus
) ;

ALTER TABLE EDITracking
       ADD CONSTRAINT pk_EDITracking_DocID PRIMARY KEY (DocID) 
	    
 ;



CREATE TABLE EDIEnvelope (
       SenderID             varchar(35) NOT NULL,
       SenderQual           varchar(25) NOT NULL,
       ReceiverID           varchar(35) NOT NULL,
       ReceiverQual         varchar(25) NOT NULL,
       EnvelopeID           char(24) NOT NULL
)ROW_FORMAT=DYNAMIC
    ;

CREATE UNIQUE INDEX idx_EDIEnvelope ON EDIEnvelope
(
	SenderID, SenderQual, ReceiverID, ReceiverQual
) ;

ALTER TABLE EDIEnvelope
       ADD CONSTRAINT pk_EDIEnvelope PRIMARY KEY (EnvelopeID)
	    
 ;



CREATE TABLE EDIEnvelopeInfo (
       EnvelopeID           char(24)NOT NULL,
       ProductionMode       integer NOT NULL,
       InbndInfo            blob,       
       OutbndInfo           blob     
)ROW_FORMAT=DYNAMIC
    ;

ALTER TABLE EDIEnvelopeInfo
       ADD CONSTRAINT pk_EDIEnvelopeInfo PRIMARY KEY (EnvelopeID, ProductionMode) 
	    
 ;

ALTER TABLE EDIEnvelopeInfo
       ADD CONSTRAINT fk_EDIEnvInfo_EnvId_EDIEnv FOREIGN KEY (EnvelopeID)
	                        REFERENCES EDIEnvelope(EnvelopeID) ;



CREATE TABLE EDIGroup (
       GroupSenderID        varchar(35) NOT NULL,
       GroupSenderQual      varchar(25) NOT NULL,
       GroupReceiverID      varchar(35) NOT NULL,
       GroupReceiverQual    varchar(25) NOT NULL,
       GroupID              char(24) NOT NULL,
       EnvelopeID           char(24) NOT NULL
)ROW_FORMAT=DYNAMIC
    ;

ALTER TABLE EDIGroup 
       ADD CONSTRAINT pk_EDIGroup PRIMARY KEY (GroupSenderID, GroupSenderQual, GroupReceiverID, GroupReceiverQual)
	    
 ;

ALTER TABLE EDIGroup 
       ADD CONSTRAINT fk_EDIGroup_EnvId_EDIEnvelope FOREIGN KEY (EnvelopeID)
	                        REFERENCES EDIEnvelope(EnvelopeID) ;



CREATE TABLE EDIControlNumber (
       EDICtrlID            integer NOT NULL,	
       SenderID             varchar(35) NOT NULL,
       SenderQual           varchar(25) NOT NULL,
       ReceiverID           varchar(35) NOT NULL,
       ReceiverQual         varchar(25) NOT NULL,
       Standard             varchar(30) NOT NULL,
       ProductionMode       integer NOT NULL,
       Version              varchar(10) NOT NULL,
       GroupType            varchar(10) NOT NULL,
       ControlNumber        decimal(30,0) NOT NULL,
       ControlNumberCap     decimal(30,0) NOT NULL,
       ControlNumberMin     decimal(30,0) NOT NULL,
       ControlNumberInc     integer NOT NULL,
       ControlNumberWindow  integer NOT NULL
)ROW_FORMAT=DYNAMIC
    ;

CREATE INDEX idx_EDIControlNumber_EDICtrlID ON EDIControlNumber
(
       EDICtrlID
) ;

ALTER TABLE EDIControlNumber
       ADD CONSTRAINT pk_EDIControlNum 
       PRIMARY KEY (SenderID, SenderQual, ReceiverID, ReceiverQual,
			  Standard, ProductionMode, Version, GroupType) 
			   
 ;



CREATE TABLE EDI_QUALIFIER_INFO (
	MapId		VARCHAR(35) NOT NULL,
	IDType		INTEGER NOT NULL,
	Qualifier	VARCHAR(35) NOT NULL
)ROW_FORMAT=DYNAMIC
   
   
;

ALTER TABLE EDI_QUALIFIER_INFO
      ADD  ( CONSTRAINT pk_EDI_QINFO_MapId PRIMARY KEY (MapId)   )
 ;
      



CREATE TABLE EDIStatus (
	EDICtrlID			integer NOT NULL,
	TNDocID			char(24) NOT NULL,
	ControlNumber		decimal(30,0) NOT NULL,
	Reason			integer NOT NULL,
	LockTimeStamp		timestamp(3) DEFAULT 0,
	TimeCreated			timestamp(3) NOT NULL
)ROW_FORMAT=DYNAMIC
    ;

CREATE INDEX idx_EDIStatus_EDICtrlID ON EDIStatus
(
       EDICtrlID 
) ;

ALTER TABLE EDIStatus 
       ADD CONSTRAINT pk_EDIStatus_TNDocID PRIMARY KEY (TNDocID)
	    
;


-- Profile DLS tables


CREATE TABLE DLSRule 
(
	DLSRuleID				CHAR(24) NOT NULL,
	Name					VARCHAR(255) NOT NULL,
	Description				VARCHAR(1024),
	AllowAny				INTEGER DEFAULT 0,
	AllowSelf				INTEGER DEFAULT 0,
	AllowAllTransactions			INTEGER DEFAULT 0,
	AllowAllProcRules			INTEGER DEFAULT 0,
	PartnerCriteria				SMALLINT DEFAULT 0 NOT NULL ,
	DocTypeCriteria				SMALLINT DEFAULT 0 NOT NULL ,
	ProcRuleCriteria			SMALLINT DEFAULT 0 NOT NULL 
)ROW_FORMAT=DYNAMIC
    ;

ALTER TABLE DLSRule 
       ADD CONSTRAINT pk_DLSRule PRIMARY KEY (DLSRuleID)
		 
;


CREATE TABLE DLSRuleRole 
(
	DLSRuleRoleID		CHAR(24) NOT NULL,
	DLSRuleID			CHAR(24) NOT NULL,
	RoleName			VARCHAR(128) NOT NULL
)ROW_FORMAT=DYNAMIC
    ;

ALTER TABLE DLSRuleRole 
       ADD CONSTRAINT pk_DLSRuleRole PRIMARY KEY (DLSRuleRoleID)
	    
 ;

ALTER TABLE DLSRuleRole
       ADD CONSTRAINT fk_DLSRuRo_DLSRule FOREIGN KEY (DLSRuleID)
	                        REFERENCES DLSRule(DLSRuleID)
;

CREATE INDEX idx_DLSRulR_RuleID ON DLSRuleRole
(
       DLSRuleID 
) ;

CREATE INDEX idx_DLSRulR_RolNam ON DLSRuleRole
(
       RoleName 
) ;

	

CREATE TABLE DLSPermission 
(
	DLSPermissionID		CHAR(24) NOT NULL,
	DLSRuleRoleID		CHAR(24) NOT NULL,
	Permission			VARCHAR(20)
)ROW_FORMAT=DYNAMIC
    ;

ALTER TABLE DLSPermission 
       ADD CONSTRAINT pk_DLSPermission PRIMARY KEY (DLSPermissionID)
	    
 ;
ALTER TABLE DLSPermission
       ADD CONSTRAINT fk_DLSPerm_DLSRole FOREIGN KEY (DLSRuleRoleID)
	                        REFERENCES DLSRuleRole (DLSRuleRoleID)
;

CREATE INDEX idx_DLSPerm_RRolID ON DLSPermission
(
       DLSRuleRoleID 
) ;

CREATE INDEX idx_DLSPerm_Permsn ON DLSPermission
(
       Permission 
) ;

	

CREATE TABLE DLSPartnerCriteria 
(
	DLSPartnerCriteriaID 	CHAR(24) NOT NULL,
	DLSRuleID				CHAR(24) NOT NULL,
	PartnerID				CHAR(24) NOT NULL
)ROW_FORMAT=DYNAMIC
    ;

ALTER TABLE DLSPartnerCriteria 
       ADD CONSTRAINT pk_DLSPtnrCriteria PRIMARY KEY (DLSPartnerCriteriaID)
	    
 ;
ALTER TABLE DLSPartnerCriteria
       ADD CONSTRAINT fk_DLSPCri_DLSRule FOREIGN KEY (DLSRuleID)
	                        REFERENCES DLSRule (DLSRuleID)
;
ALTER TABLE DLSPartnerCriteria
       ADD CONSTRAINT fk_DLSPCri_Partner FOREIGN KEY (PartnerID)
	                        REFERENCES Partner (PartnerID)
;

CREATE INDEX idx_DLSPCri_RuleID ON DLSPartnerCriteria
(
       DLSRuleID 
) ;

	


CREATE TABLE DLSProfileGroupCriteria (
	DLSProfileGroupCriteriaID	CHAR(24) NOT NULL, 
	DLSRuleID			CHAR(24) NOT NULL, 
	GroupID				CHAR(24) NOT NULL
)ROW_FORMAT=DYNAMIC
    ;

ALTER TABLE DLSProfileGroupCriteria 
       ADD CONSTRAINT pk_DLSProGroupCri PRIMARY KEY (DLSProfileGroupCriteriaID)
	    
 ;
ALTER TABLE DLSProfileGroupCriteria
       ADD CONSTRAINT fk_DLSPGCri_DLSRul FOREIGN KEY (DLSRuleID)
	                        REFERENCES DLSRule(DLSRuleID)
;
ALTER TABLE DLSProfileGroupCriteria
       ADD CONSTRAINT fk_DLSPGCri_ProGrp FOREIGN KEY (GroupID)
	                        REFERENCES ProfileGroup(GroupID)
;

CREATE INDEX idx_DLSPGCri_RulID ON DLSProfileGroupCriteria
(
       DLSRuleID 
) ;

CREATE INDEX idx_DLSPGCri_GrpID ON DLSProfileGroupCriteria
(
       GroupID 
) ;


CREATE TABLE DLSBizDocTypeDefCriteria (
	DLSBizDocTypeDefCriteriaID	CHAR(24) NOT NULL, 
	DLSRuleID					CHAR(24) NOT NULL, 
	TypeID						CHAR(24) NOT NULL
)ROW_FORMAT=DYNAMIC
    ;

ALTER TABLE DLSBizDocTypeDefCriteria 
       ADD CONSTRAINT pk_DLSBDTCri PRIMARY KEY (DLSBizDocTypeDefCriteriaID)
	    
 ;
ALTER TABLE DLSBizDocTypeDefCriteria
       ADD CONSTRAINT fk_DLSBDTCr_DLSRul FOREIGN KEY (DLSRuleID)
	                        REFERENCES DLSRule (DLSRuleID)
;
ALTER TABLE DLSBizDocTypeDefCriteria
       ADD CONSTRAINT fk_DLSBDTCr_ProGrp FOREIGN KEY (TypeID)
	                        REFERENCES BizDocTypeDef (TypeID)
;

CREATE INDEX idx_DLSBDTCri_RuID ON DLSBizDocTypeDefCriteria
(
       DLSRuleID 
) ;


CREATE TABLE DLSProcessingRuleCriteria (
	DLSProcRuleCriteriaID				CHAR(24) NOT NULL, 
	DLSRuleID					CHAR(24) NOT NULL, 
	RuleID						CHAR(24) NOT NULL
)ROW_FORMAT=DYNAMIC
    ;

ALTER TABLE DLSProcessingRuleCriteria 
       ADD CONSTRAINT pk_DLSPRCri PRIMARY KEY (DLSProcRuleCriteriaID)
	    
 ;
ALTER TABLE DLSProcessingRuleCriteria
       ADD CONSTRAINT fk_DLSPRCr_DLSRul FOREIGN KEY (DLSRuleID)
	                        REFERENCES DLSRule (DLSRuleID)
;
ALTER TABLE DLSProcessingRuleCriteria
       ADD CONSTRAINT fk_DLSPRCr_ProRule FOREIGN KEY (RuleID)
	                        REFERENCES ProcessingRule(RuleID)
;

CREATE INDEX idx_DLSPRCri_RuID ON DLSProcessingRuleCriteria
(
       DLSRuleID 
) ;

CREATE TABLE RBAFunctionalPrivileges (
	FunctionalPrivilegeID		CHAR(24) NOT NULL,
	Permission					VARCHAR(20) NOT NULL,
	RoleName					VARCHAR(128) NOT NULL
)ROW_FORMAT=DYNAMIC
    ;

ALTER TABLE RBAFunctionalPrivileges 
       ADD CONSTRAINT pk_RBAFnPriv PRIMARY KEY (FunctionalPrivilegeID)
	    
 ;

CREATE INDEX idx_Permission ON RBAFunctionalPrivileges
(
       Permission 
) ;

CREATE INDEX idx_RBAFnPriv_Role ON RBAFunctionalPrivileges
(
       RoleName
) ;

	
CREATE TABLE ArchiveService (
      ServiceName            	VARCHAR(128) NOT NULL,
      ServiceDescription	VARCHAR(1024) NULL,
      ServiceState	 	VARCHAR(12) NOT NULL,
      ServiceAction	 	VARCHAR(12) NOT NULL,
      SenderID			CHAR(24) NULL,
      ReceiverID		CHAR(24) NULL,
      DocTypeID			CHAR(24) NULL,
      ProcessingStatus		VARCHAR(20) NULL,
      UserStatus		VARCHAR(255) NULL,
      AfterDays			DOUBLE NULL,
      BatchSize			INTEGER NULL,
      BackOffTime		INTEGER NULL,	
      MaxRows			INTEGER NULL,
      Options			BLOB NOT NULL,
      Schedule			BLOB NOT NULL,
      Created		   	TIMESTAMP(3) NULL,
      LastModified         	TIMESTAMP(3) NULL,
      DeletionType		VARCHAR(25) NULL
)ROW_FORMAT=DYNAMIC
   
	
;

ALTER TABLE ArchiveService
	ADD  ( CONSTRAINT pk_ArchiveService_ServiceID PRIMARY KEY (ServiceName)   )
 ;

ALTER TABLE ArchiveService
	ADD  ( CONSTRAINT fk_ArchiveService_RecvId_Ptnr FOREIGN KEY (ReceiverID)
	     REFERENCES Partner (PartnerID)) ;

ALTER TABLE ArchiveService
	ADD  ( CONSTRAINT fk_ArchiveService_SndrId_Ptnr FOREIGN KEY (SenderID)
	     REFERENCES Partner (PartnerID) ) ;

ALTER TABLE ArchiveService
	ADD  ( CONSTRAINT fk_BizDoc_DocTyId_BDTypDef FOREIGN KEY (DocTypeID)
	REFERENCES BizDocTypeDef (TypeID)) ;
	

CREATE TABLE FX_RoutingStatus
(
	RoutingStatus        VARCHAR(30) NOT NULL
)ROW_FORMAT=DYNAMIC
;

ALTER TABLE FX_RoutingStatus
      ADD  ( CONSTRAINT pk_FXRoutingStatus_RStatus PRIMARY KEY (RoutingStatus)   )
 ;



CREATE TABLE FX_UserStatus
(
	UserStatus        VARCHAR(255) NOT NULL
)ROW_FORMAT=DYNAMIC
;

ALTER TABLE FX_UserStatus
      ADD  ( CONSTRAINT pk_FXUserStatus_UStatus PRIMARY KEY (UserStatus)   )
 ;


CREATE TABLE Rprt_Resource_Lookup
(
	Rprt_ResLookup_ID    INTEGER(5) NOT NULL,
	ResourceName         VARCHAR(25) NOT NULL,
	ResourceKey          VARCHAR(25) NOT NULL,
	Value_EN             VARCHAR(25),
	Value_DE             VARCHAR(25),
	Value_FR             VARCHAR(25),
	Value_JA             VARCHAR(25),
	Value_CS             VARCHAR(25),
	Value_DA             VARCHAR(25),
	Value_EL             VARCHAR(25),
	Value_ES             VARCHAR(25),
	Value_FI             VARCHAR(25),
	Value_HU             VARCHAR(25),
	Value_ID             VARCHAR(25),
	Value_IT             VARCHAR(25),
	Value_KO             VARCHAR(25),
	Value_MS             VARCHAR(25),
	Value_NL             VARCHAR(25),
	Value_NO             VARCHAR(25),
	Value_PL             VARCHAR(25),
	Value_PT             VARCHAR(25),
	Value_RU             VARCHAR(25),
	Value_SC             VARCHAR(25),
	Value_SV             VARCHAR(25),
	Value_TC             VARCHAR(25),
	Value_TH             VARCHAR(25)
)ROW_FORMAT=DYNAMIC   

;

CREATE  UNIQUE INDEX idx_RprtResLookup ON 
Rprt_Resource_Lookup (ResourceName, ResourceKey)  
;

ALTER TABLE Rprt_Resource_Lookup
      ADD  ( CONSTRAINT pk_ResLkup_LookupID PRIMARY KEY (Rprt_ResLookup_ID)   )
 ;
      



CREATE TABLE Template (
	TemplateID		CHAR(24) NOT NULL, 
	TemplateName		VARCHAR(256) NOT NULL, 
	TemplateDescription	VARCHAR(1024) NULL,
	CustomService		VARCHAR(256) NULL, 
	Enabled			SMALLINT NOT NULL
)ROW_FORMAT=DYNAMIC
    ;

ALTER TABLE Template 
       ADD CONSTRAINT pk_TemplateID PRIMARY KEY (TemplateID)
	    
;

CREATE INDEX idx_Template_Name ON Template
(
       TemplateName 
) ;



CREATE TABLE TemplateFieldGroupDefs (
       TemplateGroupID  CHAR(24) NOT NULL,
       Name	    	VARCHAR(256) NOT NULL,
       Description  	VARCHAR(1024) NULL
)ROW_FORMAT=DYNAMIC
   
   
;

ALTER TABLE TemplateFieldGroupDefs
       ADD CONSTRAINT pk_TemplateGroupID_ID PRIMARY KEY (TemplateGroupID) 
	    
 ;



CREATE TABLE TemplateFieldDefs (
       TemplateFieldID      CHAR(24) NOT NULL,
       Name                 VARCHAR(256) NULL,
       Required             SMALLINT NOT NULL,
       Standard		    SMALLINT NOT NULL,
       Registration         SMALLINT NOT NULL,
       ValidValues          VARCHAR(4000) NULL,
       DefaultValue         VARCHAR(128) NULL,
       ProfileTbl           VARCHAR(20) NULL,
       DataType             VARCHAR(10) NULL,
       ProfileCol           VARCHAR(20) NULL,
       Deleted              SMALLINT NOT NULL,
       TemplateGroupID      char(24) NOT NULL,
       Description          VARCHAR(1024) NULL,
       MaxLength            INTEGER NULL,
       Display              SMALLINT NOT NULL
)ROW_FORMAT=DYNAMIC
    ;

CREATE INDEX idx_TmpltFld_ProfTbl_ProfCol ON TemplateFieldDefs
(
       ProfileTbl                     ASC,
       ProfileCol                     ASC
) ;

CREATE INDEX idx_TmpltFld_Name ON TemplateFieldDefs
(
       Name                           ASC
) ;

CREATE INDEX idx_TmpltFld_GroupId ON TemplateFieldDefs
(
       TemplateGroupID                        ASC
) ;

ALTER TABLE TemplateFieldDefs
       ADD  ( CONSTRAINT pk_TmpltFld_TmpltFldId PRIMARY KEY (TemplateFieldID)   )
 ;

ALTER TABLE TemplateFieldDefs
	ADD CONSTRAINT fk_TmpFld_TmpGrpID_TmpFldGrp FOREIGN KEY (TemplateGroupID)
			   REFERENCES TemplateFieldGroupDefs (TemplateGroupID) ;



CREATE TABLE TemplateField (
      TemplateID	  	CHAR(24) NOT NULL,
      TemplateFieldID     	CHAR(24) NOT NULL,
      FieldOrder	        VARCHAR(24) NOT NULL
)ROW_FORMAT=DYNAMIC
   
   
;

CREATE INDEX idx_Template_FieldId ON TemplateField
(
      TemplateID                         ASC
) ;

ALTER TABLE TemplateField
       ADD  ( CONSTRAINT pk_Tmplt_TmpId_TmpFldId PRIMARY KEY (TemplateID, TemplateFieldID)   )
 ;

ALTER TABLE TemplateField
       ADD  ( CONSTRAINT fk_TmpltFld_TmpId FOREIGN KEY (TemplateID)
                             REFERENCES Template (TemplateID) ) ;

ALTER TABLE TemplateField
       ADD  ( CONSTRAINT fk_TmpltFld_FldId  FOREIGN KEY (TemplateFieldID)
                             REFERENCES TemplateFieldDefs (TemplateFieldID)) ;



CREATE TABLE OnboardingInvite
(
	InviteID		CHAR(24) NOT NULL,
	InviteName		VARCHAR(255) NOT NULL,
	Description		VARCHAR(1024) NULL,
	EmailFrom		VARCHAR(255) NULL,	
	Subject			VARCHAR(1024) NULL,
	InviteText		VARCHAR(4000) NULL,
	Status			VARCHAR(20) NOT NULL,
	SendDate		TIMESTAMP(3) NULL,
	ExpiryDate		TIMESTAMP(3) NULL,
	AlertDate		TIMESTAMP(3) NULL,
	ScheduleData           	BLOB NULL,
	LastSent		TIMESTAMP(3) NULL DEFAULT 0,
	TimeCreated		TIMESTAMP(3) NOT NULL,
	LastModified		TIMESTAMP(3) NULL,
	CreatedUser		VARCHAR(255) NOT NULL,
  	InvitationSent SMALLINT NOT NULL,
  	ReminderSet SMALLINT NOT NULL 
)ROW_FORMAT=DYNAMIC
 ;

ALTER TABLE OnboardingInvite
       ADD  ( CONSTRAINT pk_Invite_InviteId PRIMARY KEY (InviteID)   )
 ;



CREATE TABLE OnboardingInviteTemplate(
	InviteID		CHAR(24) NOT NULL,
	TemplateID		CHAR(24) NOT NULL
)ROW_FORMAT=DYNAMIC
;

ALTER TABLE OnboardingInviteTemplate
      ADD  ( CONSTRAINT pk_InviteTemplate PRIMARY KEY (InviteID, TemplateID)   )
 ;


ALTER TABLE OnboardingInviteTemplate
       ADD  ( CONSTRAINT fk_InviteTmplt_InviteId_Invite FOREIGN KEY (InviteID)
                             REFERENCES OnboardingInvite (InviteID)) ;

ALTER TABLE OnboardingInviteTemplate
       ADD  ( CONSTRAINT fk_InviteTmplt_TmpltId_Tmplt FOREIGN KEY (TemplateID)
                             REFERENCES Template (TemplateID)) ;


CREATE TABLE OnboardingInvitePartner(
	InviteID		CHAR(24) NOT NULL,
	PartnerID		CHAR(24) NOT NULL
)ROW_FORMAT=DYNAMIC
;

ALTER TABLE OnboardingInvitePartner
      ADD  ( CONSTRAINT pk_InvitePtnr_InviteId_PtnrId PRIMARY KEY (InviteID, PartnerID)   )
 ;


ALTER TABLE OnboardingInvitePartner
       ADD  ( CONSTRAINT fk_InvitePtnr_InviteId_Invite FOREIGN KEY (InviteID)
                             REFERENCES OnboardingInvite (InviteID)) ;

ALTER TABLE OnboardingInvitePartner
       ADD  ( CONSTRAINT fk_InvitePtnr_PtnrId_Ptnr FOREIGN KEY (PartnerID)
                             REFERENCES Partner (PartnerID)) ;

CREATE TABLE OnboardingQuestionnaireData(
	TemplateID		CHAR(24) NOT NULL,
	PartnerID		CHAR(24) NOT NULL,
	QuestionnaireData	BLOB NULL,
	Status			VARCHAR(12) NOT NULL DEFAULT 0,
	DateReceived		TIMESTAMP(3) NOT NULL
)ROW_FORMAT=DYNAMIC
;

ALTER TABLE OnboardingQuestionnaireData
      ADD  ( CONSTRAINT pk_QuestionnaireData PRIMARY KEY (TemplateID, PartnerID)   )
 ;

ALTER TABLE OnboardingQuestionnaireData
       ADD  ( CONSTRAINT fk_QustnrData_TmpltId_Tmplt FOREIGN KEY (TemplateID)
                             REFERENCES Template (TemplateID)) ;
                             
ALTER TABLE OnboardingQuestionnaireData
       ADD  ( CONSTRAINT fk_QustnrData_PtnrId_Ptnr FOREIGN KEY (PartnerID)
                             REFERENCES Partner (PartnerID)) ;

-- *************************************Dashboards Schema***********************************************************							 
CREATE TABLE TransactionSummaryData (      
      SenderID             CHAR(24)     NOT NULL,
      ReceiverID           CHAR(24)     NOT NULL,
      DocTypeID            CHAR(24)     NOT NULL,      
      HalfHour             SMALLINT     NOT NULL,
      TransactionDate      DATE         NOT NULL,
      TotalCount           INTEGER      NOT NULL      
)ROW_FORMAT=DYNAMIC;

ALTER TABLE TransactionSummaryData
      ADD  CONSTRAINT pk_TxnSummaryDataID PRIMARY KEY (SenderID, ReceiverID, DocTypeID, HalfHour, TransactionDate);

CREATE INDEX idx_TxnDate ON TransactionSummaryData
(
       TransactionDate
);

CREATE INDEX idx_DId_HH_TxnDate ON TransactionSummaryData
(       
       DocTypeID, 
       HalfHour, 
       TransactionDate
);

CREATE INDEX idx_HH_TxnDate ON TransactionSummaryData
(       
       HalfHour, 
       TransactionDate
);


CREATE INDEX idx_SId_TxnDate ON TransactionSummaryData
(          
       SenderID,
       TransactionDate
);

CREATE INDEX idx_DId_HH_SId_TxnDate ON TransactionSummaryData
(       
      DocTypeID,
      HalfHour,       
      SenderID,
      TransactionDate
);

CREATE INDEX idx_HH_SId_TxnDate ON TransactionSummaryData
(       
      HalfHour,       
      SenderID,
      TransactionDate
);


CREATE INDEX idx_RId_TxnDate ON TransactionSummaryData
(             
      ReceiverID,
      TransactionDate
);

CREATE INDEX idx_SId_RId_TxnDate ON TransactionSummaryData
(             
      SenderID,
      ReceiverID,
      TransactionDate
);

CREATE INDEX idx_HH_SId_RId_TxnDate ON TransactionSummaryData
(             
      HalfHour,
      SenderID,
      ReceiverID,
      TransactionDate
);

CREATE INDEX idx_SId_RId_DId_TxnDate ON TransactionSummaryData
(             
      SenderID,
      ReceiverID,
      DocTypeID, 
      TransactionDate
);

CREATE INDEX idx_RId_DId_TxnDate ON TransactionSummaryData
(             
      ReceiverID,
      DocTypeID, 
      TransactionDate
);

CREATE TABLE CustomAttributeVolumeValue (      
	  TransactionDate      DATE          NOT NULL,
	  HalfHour             SMALLINT      NOT NULL, 
    CustomAttributeID    CHAR(24)      NOT NULL, 
    TransactionVolume    INTEGER       NOT NULL, 
	  AttributeTotalValue  FLOAT 		     NOT NULL,  	  
    SenderID             CHAR(24)      NOT NULL,
    ReceiverID           CHAR(24)      NOT NULL          
)ROW_FORMAT=DYNAMIC;

ALTER TABLE CustomAttributeVolumeValue
      ADD  ( CONSTRAINT pk_CustAttribVolVal PRIMARY KEY (TransactionDate, HalfHour, CustomAttributeID, SenderID, ReceiverID) )
;

CREATE INDEX idx_VolValDate ON CustomAttributeVolumeValue
(
       TransactionDate
	   
);

CREATE INDEX idx_VolValAttr ON CustomAttributeVolumeValue
(       
       CustomAttributeID 
	   
);

CREATE INDEX idx_VolValSender ON CustomAttributeVolumeValue
(       
       SenderID
	   
);

CREATE INDEX idx_VolValReceiver ON CustomAttributeVolumeValue
(       
       ReceiverID
	   
);

CREATE INDEX idx_VolValDateAttr ON CustomAttributeVolumeValue
(       
     TransactionDate,
	   CustomAttributeID
	   
);

CREATE INDEX idx_VolValDateAttrSidRid ON CustomAttributeVolumeValue
(       
     TransactionDate,
	   CustomAttributeID,
	   SenderID,
	   ReceiverID
	   
);

CREATE TABLE TransactionSuccessFailedData (  
	  ID   				         CHAR(24)      NOT NULL,
	  TransactionDate      DATE          NULL,
	  HalfHour             SMALLINT      NULL, 	  
    SenderID             CHAR(24)      NULL,
    ReceiverID           CHAR(24)      NULL,
	  ProcessingStatus     SMALLINT      NULL,
	  TotalCount  		     INTEGER       NOT NULL
)ROW_FORMAT=DYNAMIC;

ALTER TABLE TransactionSuccessFailedData
      ADD  ( CONSTRAINT pk_TranxSuccessFailed PRIMARY KEY (ID) )
;

CREATE INDEX idx_TranxSFDate ON TransactionSuccessFailedData
(
       TransactionDate
	   
);

CREATE INDEX idx_TranxSFSid ON TransactionSuccessFailedData
(
       SenderID
	   
);

CREATE INDEX idx_TranxSFRid ON TransactionSuccessFailedData
(
       ReceiverID
	   
);

CREATE INDEX idx_TranxSFDateHhSidRidPs ON TransactionSuccessFailedData
(
       TransactionDate,
	   HalfHour,
	   SenderID,
	   ReceiverID,
	   ProcessingStatus	   
	   
);

CREATE TABLE SuccessFailedChartDocIdMap (       
      DocId                  CHAR(24)      NOT NULL,
      SFCHARTROWID           CHAR(24)      NOT NULL
)ROW_FORMAT=DYNAMIC
;

ALTER TABLE SuccessFailedChartDocIdMap
      ADD  ( CONSTRAINT pk_SFChartDocIdMap PRIMARY KEY (DocId) )
;

ALTER TABLE SuccessFailedChartDocIdMap
       ADD  ( CONSTRAINT fk_SFChartDocIdMap FOREIGN KEY (SFCHARTROWID)
                             REFERENCES TransactionSuccessFailedData(ID) ) ;


CREATE TABLE TransactionLateFAData (      
	  TransactionDate      DATE          NOT NULL,
	  HalfHour             SMALLINT      NOT NULL, 	  
    SenderID             CHAR(24)      NOT NULL,
    ReceiverID           CHAR(24)      NOT NULL,
	  LateFACount  		     INTEGER       NOT NULL
)ROW_FORMAT=DYNAMIC
;

ALTER TABLE TransactionLateFAData
      ADD  ( CONSTRAINT pk_TranxLateFA PRIMARY KEY (TransactionDate, HalfHour, SenderID, ReceiverID) )
;

CREATE INDEX idx_TranxLFADate ON TransactionLateFAData
(
       TransactionDate
	   
);

CREATE INDEX idx_TranxLFASid ON TransactionLateFAData
(
       SenderID
	   
);

CREATE INDEX idx_TranxLFARid ON TransactionLateFAData
(
       ReceiverID
	   
);

CREATE INDEX idx_TranxLFADateSidRid ON TransactionLateFAData
(
     TransactionDate,
	   SenderID,
	   ReceiverID
	   
);

CREATE TABLE TNASSET_READTIMEKEEPER (      
	  ASSETTYPE      		  INTEGER(2)       	NOT NULL,
	  ASSETID             CHAR(24)       		NOT NULL, 	  
    SESSIONUSER   	    CHAR(32)      		NOT NULL,
    READTIME           	TIMESTAMP(3)    	NOT NULL,
	  ROWINSERTTIME  	    TIMESTAMP(3)      NOT NULL
)ROW_FORMAT=DYNAMIC
;
ALTER TABLE TNASSET_READTIMEKEEPER
      ADD  ( CONSTRAINT ASSET_READ_TIME_KEEPER_PK PRIMARY KEY (ASSETTYPE, ASSETID, SESSIONUSER, READTIME) )
;
							 
COMMIT ;



