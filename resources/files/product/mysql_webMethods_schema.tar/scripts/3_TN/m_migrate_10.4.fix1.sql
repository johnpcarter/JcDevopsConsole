
ALTER TABLE processingrule MODIFY COLUMN RuleData longblob;
