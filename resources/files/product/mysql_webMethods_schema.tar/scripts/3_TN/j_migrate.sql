
ALTER TABLE CertificateData 
	CHANGE COLUMN ExpirationDate ExpirationDate DATETIME NOT NULL DEFAULT 0;
	
-- *************************************************************************************
-- ** OTN-18293
-- *************************************************************************************	
CREATE INDEX IDX_PARTNERID_IDTYPE_EXTID ON PartnerID
(
       IDType                ,
       ExternalID			 ,
       InternalID
) ;
	
-- *************************************************************************************
-- * Added migrateDashBoard procedure 
-- *************************************************************************************
DELIMITER //
CREATE PROCEDURE migrateDashboardCharts (batch DOUBLE, tz CHAR(6))
sp_lbl:

BEGIN
	/* Declaring variables */
	DECLARE totcount DOUBLE;
	DECLARE startValue DOUBLE;
	DECLARE endValue DOUBLE;
 
	IF (batch <= 0 ) OR  (batch IS NULL) THEN
	SELECT 'Batch size can not be 0 or less or NULL'; 
	LEAVE sp_lbl;
	END IF; 
	
    SELECT CONCAT('Starting migration of dashboard chart data with parameters, batch: ' , ifnull(batch, '') ,', tz: ' , ifnull(tz, ''));
	SELECT CONCAT('Dashboard Migration process started at: ' , DATE_FORMAT(SYSDATE(), '%d-%m-%Y %H:%i:%s')); 
	/* Deleting all chart summary data*/
    
    PREPARE truncateTransactionSummaryData FROM 'TRUNCATE TABLE TRANSACTIONSUMMARYDATA';
	EXECUTE truncateTransactionSummaryData;
    
	PREPARE truncateTableCustomAttributeVolumeValue FROM 'TRUNCATE TABLE CUSTOMATTRIBUTEVOLUMEVALUE';
    EXECUTE truncateTableCustomAttributeVolumeValue;
	
    
	SET SQL_SAFE_UPDATES=0;
    SET foreign_key_checks = 0;
    PREPARE deleteFromTransactionSuccessFailedData FROM 'DELETE FROM TRANSACTIONSUCCESSFAILEDDATA';
    EXECUTE deleteFromTransactionSuccessFailedData;
    
	PREPARE truncateSuccessFailedChartDocIdMap FROM 'TRUNCATE TABLE SUCCESSFAILEDCHARTDOCIDMAP';
	EXECUTE truncateSuccessFailedChartDocIdMap;
    
    PREPARE truncateTableTransactionLateFaData FROM 'TRUNCATE TABLE TRANSACTIONLATEFADATA';
	EXECUTE truncateTableTransactionLateFaData;
    
    
	SELECT 'Deleted all dashboard summary table data.';
    
	/* Start: Migration of TransactionSummaryData */		
	SELECT  count(*) INTO totcount FROM (
	SELECT SENDERID, RECEIVERID, DOCTYPEID, TRANSACTIONDATE, HALFHOUR, COUNT(DOCID)AS TOTALCOUNT
			FROM (
				SELECT 
					DOCID,
					SENDERID,
					RECEIVERID,
					DOCTYPEID,
					DATE_FORMAT(CAST(convert_tz(DOCTIMESTAMP,@@session.time_zone,'+00:00') AS DATETIME),'%Y-%m-%d')AS TRANSACTIONDATE ,
					
                    (2 * EXTRACT(HOUR FROM CAST(convert_tz(DOCTIMESTAMP,@@session.time_zone,'+00:00') AS DATETIME))) +
					SIGN (
					  SIGN(
						EXTRACT(MINUTE 
						  FROM CAST(convert_tz(DOCTIMESTAMP,@@session.time_zone,'+00:00') AS DATETIME)
						) - 30
					  ) + 1
					) AS HALFHOUR
                    
				FROM BIZDOC
				WHERE ROUTINGSTATUS IN ('DONE', 'DONE W/ ERRORS', 'RESUBMITTED', 'REPROCESSED', 'RESUBMITTED W/ ERROR', 'REPROCESSED W/ ERROR', 'POLLABLE', 'QUEUED')
			) AS BIZDOC_COUNT_INNER
			GROUP BY SENDERID, RECEIVERID, DOCTYPEID, TRANSACTIONDATE, HALFHOUR
	) AS BIZDOC_COUNT;
    
    /* Section for Insert operation*/

    SET startValue = 1;
	SET endValue = batch;
    SET @rowNumber = 0;
    
	SELECT CONCAT('Migrating TRANSACTIONSUMMARYDATA, total number of aggregated records       : ' , ifnull(totcount, '')); 
	WHILE totcount > 0
	DO
   
		INSERT INTO TRANSACTIONSUMMARYDATA(SENDERID, RECEIVERID, DOCTYPEID, TRANSACTIONDATE, HALFHOUR, TOTALCOUNT)
		SELECT SENDERID, RECEIVERID, DOCTYPEID, TRANSACTIONDATE, HALFHOUR, TOTALCOUNT
		FROM (
		SELECT SENDERID, RECEIVERID, DOCTYPEID, TRANSACTIONDATE, HALFHOUR, COUNT(DOCID)AS TOTALCOUNT, (@rowNumber:=@rowNumber + 1) as row1
			FROM (
				SELECT 
					DOCID,
					SENDERID,
					RECEIVERID, 
					DOCTYPEID,
					DATE_FORMAT(CAST(convert_tz(DOCTIMESTAMP,@@session.time_zone,'+00:00') AS DATETIME),'%Y-%m-%d')AS TRANSACTIONDATE ,
					 
                     (2 * EXTRACT(HOUR FROM CAST(convert_tz(DOCTIMESTAMP,@@session.time_zone,'+00:00') AS DATETIME))) +
					  SIGN (
					  SIGN(
						EXTRACT(MINUTE 
						  FROM CAST(convert_tz(DOCTIMESTAMP,@@session.time_zone,'+00:00') AS DATETIME)
						) - 30
					  ) + 1
					) AS HALFHOUR
                    
				FROM BIZDOC
				WHERE ROUTINGSTATUS IN ('DONE', 'DONE W/ ERRORS', 'RESUBMITTED', 'REPROCESSED', 'RESUBMITTED W/ ERROR', 'REPROCESSED W/ ERROR', 'POLLABLE', 'QUEUED')
			) AS BIZDOC_INSERT_INNER
			GROUP BY SENDERID, RECEIVERID, DOCTYPEID, TRANSACTIONDATE, HALFHOUR ORDER BY SENDERID,RECEIVERID,DOCTYPEID,TRANSACTIONDATE,HALFHOUR
		) AS BIZDOC_INSERT
		WHERE row1 BETWEEN startValue AND endValue;
		COMMIT;	
		SET startValue = startValue + batch;
		SET endValue = endValue + batch;
		SET totcount = totcount-batch;
        SET @rowNumber = 0; 
		END WHILE;

    /* End of insert section   */   
    /* End: Migration of TRANSACTIONSUMMARYDATA */
    
    /* Start: Migration of CUSTOMATTRIBUTEVOLUMEVALUE */
    
	SELECT  count(*) INTO totcount FROM  (
	SELECT SENDERID, RECEIVERID, CUSTOMATTRIBUTEID, TRANSACTIONDATE, HALFHOUR, COUNT(*) AS TRANSACTIONVOLUME, SUM(NUMBERVALUE) AS ATTRIBUTETOTALVALUE
			FROM (
				SELECT 
					D.SENDERID,
					D.RECEIVERID,
					BDA.ATTRIBUTEID AS CUSTOMATTRIBUTEID,
					DATE_FORMAT(CAST(convert_tz(DOCTIMESTAMP,@@session.time_zone,'+00:00') AS DATETIME),'%Y-%m-%d') AS TRANSACTIONDATE,
                    
					(2 * EXTRACT(HOUR FROM CAST(convert_tz(DOCTIMESTAMP,@@session.time_zone,'+00:00') AS DATETIME))) +
			         SIGN (
					  SIGN(
						EXTRACT(MINUTE 
						  FROM CAST(convert_tz(DOCTIMESTAMP,@@session.time_zone,'+00:00') AS DATETIME)
						) - 30
					  ) + 1
					) AS HALFHOUR,
					BDA.NUMBERVALUE
				FROM 
					BIZDOC D INNER JOIN BIZDOCATTRIBUTE BDA ON D.DOCID = BDA.DOCID
					INNER JOIN BIZDOCATTRIBUTEDEF BDAD ON BDA.ATTRIBUTEID = BDAD.ATTRIBUTEID
				WHERE BDAD.ATTRIBUTETYPE = 'NUMBER' AND BDAD.DELETED = 0 AND BDAD.PERSIST = 1 AND BDA.NUMBERVALUE IS NOT NULL
				AND D.ROUTINGSTATUS IN ('DONE', 'DONE W/ ERRORS', 'RESUBMITTED', 'REPROCESSED', 'RESUBMITTED W/ ERROR', 'REPROCESSED W/ ERROR', 'POLLABLE', 'QUEUED')
			) AS BIZDOC_COUNT2_INNER
			GROUP BY SENDERID, RECEIVERID, CUSTOMATTRIBUTEID, TRANSACTIONDATE, HALFHOUR
	)AS BIZDOC_COUNT2 ;
    
	SET startValue = 1;
    SET @rowNumber=0;
	SET endValue = batch;

	SELECT CONCAT('Migrating CUSTOMATTRIBUTEVOLUMEVALUE, total number of aggregated records   : ' , ifnull(totcount, ''));
	
    WHILE totcount > 0
	DO
		INSERT INTO CUSTOMATTRIBUTEVOLUMEVALUE(SENDERID, RECEIVERID, CUSTOMATTRIBUTEID, TRANSACTIONDATE, HALFHOUR, TRANSACTIONVOLUME, ATTRIBUTETOTALVALUE)
		SELECT SENDERID, RECEIVERID, CUSTOMATTRIBUTEID, TRANSACTIONDATE, HALFHOUR, TRANSACTIONVOLUME, ATTRIBUTETOTALVALUE
		FROM (
			SELECT SENDERID, RECEIVERID, CUSTOMATTRIBUTEID, TRANSACTIONDATE, HALFHOUR, COUNT(*) AS TRANSACTIONVOLUME, SUM(NUMBERVALUE) AS ATTRIBUTETOTALVALUE,  (@rowNumber:=@rowNumber + 1) as row_number1
			FROM (
				SELECT 
					D.SENDERID,
					D.RECEIVERID,
					BDA.ATTRIBUTEID AS CUSTOMATTRIBUTEID,
					DATE_FORMAT(CAST(convert_tz(DOCTIMESTAMP,@@session.time_zone,'+00:00') AS DATETIME),'%Y-%m-%d')AS TRANSACTIONDATE ,
                    
					(2 * EXTRACT(HOUR FROM CAST(convert_tz(DOCTIMESTAMP,@@session.time_zone,'+00:00') AS DATETIME))) +
					 SIGN (
					  SIGN(
						EXTRACT(MINUTE 
						  FROM CAST(convert_tz(DOCTIMESTAMP,@@session.time_zone,'+00:00') AS DATETIME)
						) - 30
					  ) + 1
					) AS HALFHOUR,
					BDA.NUMBERVALUE
				FROM 
					BIZDOC D INNER JOIN BIZDOCATTRIBUTE BDA ON D.DOCID = BDA.DOCID
					INNER JOIN BIZDOCATTRIBUTEDEF BDAD ON BDA.ATTRIBUTEID = BDAD.ATTRIBUTEID
				WHERE BDAD.ATTRIBUTETYPE = 'NUMBER' AND BDAD.DELETED = 0 AND BDAD.PERSIST = 1 AND BDA.NUMBERVALUE IS NOT NULL
				AND D.ROUTINGSTATUS IN ('DONE', 'DONE W/ ERRORS', 'RESUBMITTED', 'REPROCESSED', 'RESUBMITTED W/ ERROR', 'REPROCESSED W/ ERROR', 'POLLABLE', 'QUEUED')
			)  AS BIZDOC_INSERT2_INNER
			GROUP BY SENDERID, RECEIVERID, CUSTOMATTRIBUTEID, TRANSACTIONDATE, HALFHOUR ORDER BY SENDERID,RECEIVERID,CUSTOMATTRIBUTEID,TRANSACTIONDATE,HALFHOUR
		) AS BIZDOC_INSERT2
		WHERE row_number1 BETWEEN startValue AND endValue;
		COMMIT;	
		SET startValue = startValue + batch;
		SET endValue = endValue + batch;
		SET totcount = totcount-batch;
		SET @rowNumber = 0;
	 END WHILE;
	/* End: Migration of CUSTOMATTRIBUTEVOLUMEVALUE */
    
	/* Start: Migration of TRANSACTIONSUCCESSFAILEDDATA */	
      
        SELECT  count(*) INTO totcount FROM (
		SELECT SENDERID, RECEIVERID, PROCESSINGSTATUS, TRANSACTIONDATE, HALFHOUR, COUNT(DOCID) AS TOTALCOUNT
		FROM (
			SELECT 
				DOCID,
				SENDERID,
				RECEIVERID,
				
			CASE ROUTINGSTATUS 
			  WHEN 'DONE' THEN '1'
			  WHEN 'DONE W/ ERRORS' THEN '3'
			  WHEN 'RESUBMITTED' THEN '10'
			  WHEN 'REPROCESSED' THEN '11'
			  WHEN 'RESUBMITTED W/ ERROR' THEN '14'
			  WHEN 'REPROCESSED W/ ERROR' THEN '15'
			END AS PROCESSINGSTATUS,
        
		    DATE_FORMAT(CAST(convert_tz(DOCTIMESTAMP,@@session.time_zone,'+00:00') AS DATETIME),'%Y-%m-%d')AS TRANSACTIONDATE,
            
			(2 * EXTRACT(HOUR FROM CAST(convert_tz(DOCTIMESTAMP,@@session.time_zone,'+00:00') AS DATETIME))) +
		           SIGN (
					  SIGN(
						EXTRACT(MINUTE 
						  FROM CAST(convert_tz(DOCTIMESTAMP,@@session.time_zone,'+00:00') AS DATETIME)
						) - 30
			  ) + 1
			) AS HALFHOUR
            
		FROM BIZDOC
		WHERE ROUTINGSTATUS IN ('DONE', 'DONE W/ ERRORS', 'RESUBMITTED', 'REPROCESSED', 'RESUBMITTED W/ ERROR', 'REPROCESSED W/ ERROR')
	) AS BIZDOC_COUNT3_INNER
	GROUP BY SENDERID, RECEIVERID, PROCESSINGSTATUS, TRANSACTIONDATE, HALFHOUR 
	) AS BIZDOC_COUNT3 ;
    
    /*Section for insert operation*/
    set startValue = 1;
	set endValue = batch;
	set @rowNumber=0;
    
      set @dense_rank=0;
      set @SENDERID='';
      set @RECEIVERID='';
      set @PROCESSINGSTATUS='';
      set @TRANSACTIONDATE='';
      set @HALFHOUR='';
    
    
	SELECT CONCAT('Migrating TRANSACTIONSUCCESSFAILEDDATA, total number of aggregated records : ' , ifnull(totcount, '')); 
	WHILE totcount > 0
	DO
		INSERT INTO TRANSACTIONSUCCESSFAILEDDATA(ID, SENDERID, RECEIVERID, PROCESSINGSTATUS, TRANSACTIONDATE, HALFHOUR, TOTALCOUNT)
		SELECT ID, SENDERID, RECEIVERID, PROCESSINGSTATUS, TRANSACTIONDATE, HALFHOUR, TOTALCOUNT
		FROM (
			SELECT SENDERID, RECEIVERID, PROCESSINGSTATUS, TRANSACTIONDATE, HALFHOUR, COUNT(DOCID) AS TOTALCOUNT,
            
            (@rowNumber:=@rowNumber + 1) as row_number1,
            
            @dense_rank:=case when (@SENDERID=SENDERID and @RECEIVERID=RECEIVERID and @PROCESSINGSTATUS=PROCESSINGSTATUS 
            and @TRANSACTIONDATE=TRANSACTIONDATE and @HALFHOUR=HALFHOUR) then @dense_rank else @dense_rank+1 end as ID, 
            @SENDERID:=SENDERID as SENDERID3, @RECEIVERID:=RECEIVERID as RECEIVERID3, @PROCESSINGSTATUS:= PROCESSINGSTATUS 
            as PROCESSINGSTATUS3, @TRANSACTIONDATE:= TRANSACTIONDATE as TRANSACTIONDATE3,@HALFHOUR:= HALFHOUR as HALFHOUR3
            
			FROM (
				SELECT 
					DOCID,
					SENDERID,
					RECEIVERID,
					CASE ROUTINGSTATUS
					  WHEN 'DONE' THEN '1'
					  WHEN 'DONE W/ ERRORS' THEN '3'
					  WHEN 'RESUBMITTED' THEN '10'
					  WHEN 'REPROCESSED' THEN '11'
					  WHEN 'RESUBMITTED W/ ERROR' THEN '14'
					  WHEN 'REPROCESSED W/ ERROR' THEN '15'
					END AS PROCESSINGSTATUS,
					DATE_FORMAT(CAST(convert_tz(DOCTIMESTAMP,@@session.time_zone,'+00:00') AS DATETIME),'%Y-%m-%d')AS TRANSACTIONDATE ,
                    
			        (2 * EXTRACT(HOUR FROM CAST(convert_tz(DOCTIMESTAMP,@@session.time_zone,'+00:00') AS DATETIME))) +
					SIGN (
					  SIGN(
						EXTRACT(MINUTE 
						  FROM CAST(convert_tz(DOCTIMESTAMP,@@session.time_zone,'+00:00') AS DATETIME)
						) - 30
					  ) + 1
					) AS HALFHOUR
                    
				FROM BIZDOC
				WHERE ROUTINGSTATUS IN ('DONE', 'DONE W/ ERRORS', 'RESUBMITTED', 'REPROCESSED', 'RESUBMITTED W/ ERROR', 'REPROCESSED W/ ERROR')
			) AS BIZDOC_INSERT3_INNER
			GROUP BY SENDERID, RECEIVERID, PROCESSINGSTATUS, TRANSACTIONDATE, HALFHOUR ORDER BY SENDERID,RECEIVERID,PROCESSINGSTATUS,TRANSACTIONDATE,HALFHOUR
		) AS BIZDOC_INSERT3
		WHERE row_number1 BETWEEN startValue AND endValue;
		COMMIT;	
		SET startValue = startValue + batch;
		SET endValue = endValue + batch;
		SET totcount = totcount-batch;
		SET @rowNumber = 0; 
        SET @dense_rank = 0; 
        
	END WHILE;
	/* End: Migration of TRANSACTIONSUCCESSFAILEDDATA */
    
	/* Start: Migration of SUCCESSFAILEDCHARTDOCIDMAP */	
    
	SELECT  count(*) INTO totcount FROM (
	SELECT DOCID
	FROM (
		SELECT 
			DOCID,
			SENDERID,
			RECEIVERID,
			CASE ROUTINGSTATUS
			  WHEN 'DONE' THEN '1'
			  WHEN 'DONE W/ ERRORS' THEN '3'
			  WHEN 'RESUBMITTED' THEN '10'
			  WHEN 'REPROCESSED' THEN '11'
			  WHEN 'RESUBMITTED W/ ERROR' THEN '14'
			  WHEN 'REPROCESSED W/ ERROR' THEN '15'
			END AS PROCESSINGSTATUS,
	                DATE_FORMAT(CAST(convert_tz(DOCTIMESTAMP,@@session.time_zone,'+00:00') AS DATETIME),'%Y-%m-%d')AS TRANSACTIONDATE,
                    
					(2 * EXTRACT(HOUR FROM CAST(convert_tz(DOCTIMESTAMP,@@session.time_zone,'+00:00') AS DATETIME))) +					
				     SIGN (
					  SIGN(
						EXTRACT(MINUTE 
						  FROM CAST(convert_tz(DOCTIMESTAMP,@@session.time_zone,'+00:00') AS DATETIME)
						) - 30
			  ) + 1
			) AS HALFHOUR
            
		FROM BIZDOC
		WHERE ROUTINGSTATUS IN ('DONE', 'DONE W/ ERRORS', 'RESUBMITTED', 'REPROCESSED', 'RESUBMITTED W/ ERROR', 'REPROCESSED W/ ERROR')
	) AS BIZDOC_COUNT4_INNER
	) AS BIZDOC_COUNT4;
	
    /* Insert operation starts here*/
    
     SET startValue = 1;
	 SET endValue = batch;
    
	 SET @rowNumber=0;
	 
     set @dense_rank=0;
	 set @SENDERID='';
	 set @RECEIVERID='';
	 set @PROCESSINGSTATUS='';
	 set @TRANSACTIONDATE='';
	 set @HALFHOUR='';
      
	SELECT CONCAT('Migrating SUCCESSFAILEDCHARTDOCIDMAP, total number of records              : ' , ifnull(totcount, ''));
	WHILE totcount > 0
	DO
		INSERT INTO SUCCESSFAILEDCHARTDOCIDMAP(DOCID, SFCHARTROWID)
		SELECT DOCID, ID AS SFCHARTROWID
		FROM (
			SELECT DOCID, 
            
            (@rowNumber:=@rowNumber + 1) as row_number1, 
            
			@dense_rank:=case when (@SENDERID=SENDERID and @RECEIVERID=RECEIVERID and @PROCESSINGSTATUS=PROCESSINGSTATUS 
            and @TRANSACTIONDATE=TRANSACTIONDATE and @HALFHOUR=HALFHOUR) then @dense_rank else @dense_rank+1 end as ID, 
            @SENDERID:=SENDERID as SENDERID3, @RECEIVERID:=RECEIVERID as RECEIVERID3, @PROCESSINGSTATUS:= PROCESSINGSTATUS 
            as PROCESSINGSTATUS3, @TRANSACTIONDATE:= TRANSACTIONDATE as TRANSACTIONDATE3,@HALFHOUR:= HALFHOUR as HALFHOUR3
		
			FROM (
				SELECT 
					DOCID,
					SENDERID,
					RECEIVERID,
					CASE ROUTINGSTATUS
					  WHEN 'DONE' THEN '1'
					  WHEN 'DONE W/ ERRORS' THEN '3'
					  WHEN 'RESUBMITTED' THEN '10'
					  WHEN 'REPROCESSED' THEN '11'
					  WHEN 'RESUBMITTED W/ ERROR' THEN '14'
					  WHEN 'REPROCESSED W/ ERROR' THEN '15'
					END AS PROCESSINGSTATUS,
                    
			        DATE_FORMAT(CAST(convert_tz(DOCTIMESTAMP,@@session.time_zone,'+00:00') AS DATETIME),'%Y-%m-%d')AS TRANSACTIONDATE,
                    
					  (2 * EXTRACT(HOUR FROM CAST(convert_tz(DOCTIMESTAMP,@@session.time_zone,'+00:00') AS DATETIME))) +
					SIGN (
					  SIGN(
						EXTRACT(MINUTE 
						  FROM CAST(convert_tz(DOCTIMESTAMP,@@session.time_zone,'+00:00') AS DATETIME)
						) - 30
					  ) + 1
					) AS HALFHOUR
                    
				FROM BIZDOC
				WHERE ROUTINGSTATUS IN ('DONE', 'DONE W/ ERRORS', 'RESUBMITTED', 'REPROCESSED', 'RESUBMITTED W/ ERROR', 'REPROCESSED W/ ERROR')
			) AS BIZDOC_INSERT4_INNER order by SENDERID, RECEIVERID, PROCESSINGSTATUS, TRANSACTIONDATE, HALFHOUR
		) AS BIZDOC_INSERT4
		WHERE row_number1 BETWEEN startValue AND endValue;
		COMMIT;
		SET startValue = startValue + batch;
		SET endValue = endValue + batch;
		SET totcount = totcount-batch;
		SET @rowNumber = 0; 
        SET @dense_rank = 0; 
	END WHILE;
	/* End: Migration of SUCCESSFAILEDCHARTDOCIDMAP */
    
    /* Start: Migration of TRANSACTIONLATEFADATA */		

	SELECT  count(*) INTO totcount FROM (
	SELECT SENDERID, RECEIVERID, TRANSACTIONDATE, HALFHOUR, COUNT(*) AS LATEFACOUNT
			FROM (
				SELECT 
					D.SENDERID,
					D.RECEIVERID,
                    DATE_FORMAT(CAST(convert_tz(DOCTIMESTAMP,@@session.time_zone,'+00:00') AS DATETIME),'%Y-%m-%d')AS TRANSACTIONDATE ,
                    
					(2 * EXTRACT(HOUR FROM CAST(convert_tz(DOCTIMESTAMP,@@session.time_zone,'+00:00') AS DATETIME))) +
					SIGN (
					  SIGN(
						EXTRACT(MINUTE 
						  FROM CAST(convert_tz(DOCTIMESTAMP,@@session.time_zone,'+00:00') AS DATETIME)
						) - 30
					  ) + 1
					) AS HALFHOUR
                    
				FROM 
					BIZDOC D INNER JOIN BIZDOCATTRIBUTE BDA ON D.DOCID = BDA.DOCID
					INNER JOIN BIZDOCATTRIBUTEDEF BDAD ON BDA.ATTRIBUTEID = BDAD.ATTRIBUTEID
				WHERE 
					BDAD.ATTRIBUTETYPE = 'STRING' AND 
					BDAD.DELETED = 0 AND BDAD.PERSIST = 1 AND 
					BDAD.ATTRIBUTENAME = 'Late FA' AND BDAD.ATTRIBUTEID = 'EDILateFA---------------' AND
					BDA.STRINGVALUE = 'Y'
					AND D.ROUTINGSTATUS IN ('DONE', 'DONE W/ ERRORS', 'RESUBMITTED', 'REPROCESSED', 'RESUBMITTED W/ ERROR', 'REPROCESSED W/ ERROR', 'POLLABLE', 'QUEUED')
			) AS BIZDOC_COUNT5_INNER
			GROUP BY SENDERID, RECEIVERID, TRANSACTIONDATE, HALFHOUR
	)AS BIZDOC_COUNT5;
	
    SET startValue = 1;
	SET endValue = batch;
	SET @rowNumber=0;
    
	SELECT CONCAT('Migrating TRANSACTIONLATEFADATA, total number of aggregated records        : ' , ifnull(totcount, ''));
    
	WHILE totcount > 0 
	DO
		INSERT INTO TRANSACTIONLATEFADATA(SENDERID, RECEIVERID, TRANSACTIONDATE, HALFHOUR, LATEFACOUNT)
		SELECT SENDERID, RECEIVERID, TRANSACTIONDATE, HALFHOUR, LATEFACOUNT
		FROM (
			SELECT SENDERID, RECEIVERID, TRANSACTIONDATE, HALFHOUR, COUNT(*) AS LATEFACOUNT, (@rowNumber:=@rowNumber + 1) as row_number1
			FROM (
				SELECT 
					D.SENDERID,
					D.RECEIVERID,
                    DATE_FORMAT(CAST(convert_tz(DOCTIMESTAMP,@@session.time_zone,'+00:00') AS DATETIME),'%Y-%m-%d') AS TRANSACTIONDATE ,
                    
					(2 * EXTRACT(HOUR FROM CAST(convert_tz(DOCTIMESTAMP,@@session.time_zone,'+00:00') AS DATETIME))) + 
					SIGN (
					  SIGN(
						EXTRACT(MINUTE 
						  FROM CAST(convert_tz(DOCTIMESTAMP,@@session.time_zone,'+00:00') AS DATETIME)
						) - 30
					  ) + 1
					) AS HALFHOUR
                    
				FROM 
					BIZDOC D INNER JOIN BIZDOCATTRIBUTE BDA ON D.DOCID = BDA.DOCID
					INNER JOIN BIZDOCATTRIBUTEDEF BDAD ON BDA.ATTRIBUTEID = BDAD.ATTRIBUTEID
				WHERE 
					BDAD.ATTRIBUTETYPE = 'STRING' AND 
					BDAD.DELETED = 0 AND BDAD.PERSIST = 1 AND 
					BDAD.ATTRIBUTENAME = 'Late FA' AND BDAD.ATTRIBUTEID = 'EDILateFA---------------' AND
					BDA.STRINGVALUE = 'Y'
					AND D.ROUTINGSTATUS IN ('DONE', 'DONE W/ ERRORS', 'RESUBMITTED', 'REPROCESSED', 'RESUBMITTED W/ ERROR', 'REPROCESSED W/ ERROR', 'POLLABLE', 'QUEUED')
			) AS BIZDOC_INSERT5_INNER
			GROUP BY SENDERID, RECEIVERID, TRANSACTIONDATE, HALFHOUR order by SENDERID, RECEIVERID, TRANSACTIONDATE, HALFHOUR
		) AS BIZDOC_INSERT5
		WHERE row_number1 BETWEEN startValue AND endValue;
		COMMIT;	
		SET startValue = startValue + batch;
		SET endValue = endValue + batch;
		SET totcount = totcount-batch;
		SET @rowNumber = 0; 
	END WHILE;
	/* End: Migration of TRANSACTIONLATEFADATA */	
    END//

DELIMITER ;
