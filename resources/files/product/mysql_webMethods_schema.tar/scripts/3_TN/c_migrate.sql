CREATE TABLE DeliverySuspendSchedule  (
	Id 			CHAR(24) NOT NULL, 
	Name 			VARCHAR(100) NOT NULL, 
	Status 			INTEGER(1) NOT NULL, 
	DeliverySuspended	INTEGER(1) NOT NULL,
	PartnerID 		CHAR(24) NOT NULL , 
	ScheduleData 		BLOB NOT NULL
)ROW_FORMAT=DYNAMIC   
;
CREATE UNIQUE INDEX idx_DelSuspSch_Name ON DeliverySuspendSchedule
(
  	Name 			ASC
) ;

ALTER TABLE DeliverySuspendSchedule
       ADD ( CONSTRAINT pk_DelSuspSch_Id PRIMARY KEY (Id) )
;

ALTER TABLE DeliverySuspendSchedule
       ADD ( CONSTRAINT fk_DelSuspSch_PtnrID FOREIGN KEY(PartnerID) 
       REFERENCES Partner(PartnerID) );
       