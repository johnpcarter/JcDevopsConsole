DELIMITER //

CREATE TRIGGER pra_custom_process1 AFTER INSERT ON pra_process_custom FOR EACH ROW
BEGIN

  IF (new.instanceid <> new.customid) THEN
    UPDATE pra_process_recent SET 
      customid = new.customid
      WHERE instanceid = new.instanceid;
  END IF;

END//

DELIMITER //
