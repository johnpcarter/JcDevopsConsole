DELIMITER //
CREATE TRIGGER pra_process_recent1
  AFTER INSERT ON pra_process FOR EACH ROW
BEGIN

  DECLARE newHasParent CHAR (1);
  DECLARE recentInstanceId CHAR (36);
  DECLARE recentIter SMALLINT;
  DECLARE recentStatus INTEGER;
  DECLARE recentTime TIMESTAMP;
  DECLARE recentFirstStatus INTEGER;
  DECLARE recentFirstTime TIMESTAMP;
  DECLARE recentCategory SMALLINT;
  DECLARE newCategory SMALLINT;

  set newHasParent = 'Y';
  set recentCategory = 20;
  set newCategory = 20;

  SELECT instanceid, instanceiteration, status, audittimestamp, firststatus, firsttime
      INTO recentInstanceId, recentIter, recentStatus, recentTime, recentFirstStatus, recentFirstTime
      FROM pra_process_recent WHERE instanceid = new.instanceid;

  IF new.parentinstanceid IS NULL THEN
    set newHasParent = 'N';
  END IF;

  IF recentInstanceId IS NULL THEN
    INSERT INTO pra_process_recent 
      (instanceid, parentinstanceid, instanceiteration, audittimestamp, processkey, modelversion, 
       status, system, hasparent, customid, firsttime, firststatus, parentsteptype) 
     VALUES 
      (new.instanceid, new.parentinstanceid, new.instanceiteration, new.audittimestamp, new.processkey, new.modelversion, 
       new.status, new.system, newHasParent, new.instanceid, new.audittimestamp, new.status, new.parentsteptype);
  END IF;
     
  IF recentInstanceId IS NOT NULL THEN
    IF recentIter IS NULL THEN

      UPDATE pra_process_recent SET 
        instanceiteration = new.instanceiteration,
        parentinstanceid = new.parentinstanceid,
        audittimestamp = new.audittimestamp,
        status = new.status,
        system = new.system,
        processkey = new.processkey,
        modelversion = new.modelversion,
        hasparent = newHasParent,
        firststatus = new.status,
        firsttime = new.audittimestamp
      WHERE instanceid = new.instanceid;

    ELSEIF recentIter < new.instanceiteration THEN

      UPDATE pra_process_recent SET 
        instanceiteration = new.instanceiteration,
        parentinstanceid = new.parentinstanceid,
        audittimestamp = new.audittimestamp,
        status = new.status,
        system = new.system,
        processkey = new.processkey,
        modelversion = new.modelversion,
        hasparent = newHasParent
      WHERE instanceid = new.instanceid;

    ELSEIF recentIter = new.instanceiteration THEN
      IF new.status = 1 AND recentFirstStatus <> 1 AND new.audittimestamp <= recentFirstTime THEN

        UPDATE pra_process_recent SET 
          firststatus = new.status,
          firsttime = new.audittimestamp
        WHERE instanceid = new.instanceid;

      END IF;

      IF recentStatus = 2 OR recentStatus = 4 OR recentStatus = 1024 THEN 
        set recentCategory = 30;
      ELSEIF recentStatus = 1 THEN 
        set recentCategory = 10;
      END IF;
 
      IF new.status = 2 OR new.status = 4 OR new.status = 1024 THEN
        set newCategory = 30;
      ELSEIF new.status = 1 AND recentStatus = 32768 THEN
        set newCategory = 30;
      ELSEIF new.status = 1 THEN
        set newCategory = 10;
      END IF;

      IF newCategory > recentCategory THEN

        UPDATE pra_process_recent SET 
          instanceiteration = new.instanceiteration,
          parentinstanceid = new.parentinstanceid,
          audittimestamp = new.audittimestamp,
          status = new.status,
          system = new.system,
          processkey = new.processkey,
          modelversion = new.modelversion,
          hasparent = newHasParent
        WHERE instanceid = new.instanceid;

      ELSEIF newCategory = recentCategory AND new.audittimestamp > recentTime THEN

        UPDATE pra_process_recent SET 
          instanceiteration = new.instanceiteration,
          parentinstanceid = new.parentinstanceid,
          audittimestamp = new.audittimestamp,
          status = new.status,
          system = new.system,
          processkey = new.processkey,
          modelversion = new.modelversion,
          hasparent = newHasParent
        WHERE instanceid = new.instanceid;

      ELSEIF new.status=1 and recentStatus=32768 and new.audittimestamp > recentTime THEN

        UPDATE pra_process_recent SET 
          instanceiteration = new.instanceiteration,
          parentinstanceid = new.parentinstanceid,
          audittimestamp = new.audittimestamp,
          status = new.status,
          system = new.system,
          processkey = new.processkey,
          modelversion = new.modelversion,
          hasparent = newHasParent
        WHERE instanceid = new.instanceid;

      END IF;
    END IF;
  END IF;
END//

DELIMITER //
