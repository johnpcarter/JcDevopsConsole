
CREATE OR REPLACE VIEW WMTRANSITIONDEF_VIEW_PET as 
    select * 
      from WMSTEPTRANSITIONDEFINITION def1
     where DEPLOYMENTVERSION = (
            select MAX(DEPLOYMENTVERSION)
              from WMSTEPTRANSITIONDEFINITION def2
             where def1.PROCESSKEY = def2.PROCESSKEY
               and def1.MODELVERSION = def2.MODELVERSION
            );
            
CREATE OR REPLACE VIEW WMSTAGEDEF_VIEW_PET as 
    select * 
      from WMSTAGEDEFINITION def1
    where DEPLOYMENTVERSION = (
            select MAX(DEPLOYMENTVERSION)
              from WMSTAGEDEFINITION def2
             where def1.PROCESSKEY = def2.PROCESSKEY
               and def1.MODELVERSION = def2.MODELVERSION
                    );
