DELIMITER //
CREATE TRIGGER WMSERVICE_RAIU
  AFTER INSERT
	ON WMSERVICE
FOR EACH ROW
  BEGIN
	DECLARE prfirststatus INTEGER;
	DECLARE prfirsttime    TIMESTAMP(6);
    DECLARE prlaststatus   INTEGER;
    DECLARE prlasttime     TIMESTAMP(6);
    DECLARE prduration     INTEGER;
    DECLARE prcontextid    NCHAR (36);
    DECLARE newfirststatus INTEGER;
    DECLARE newfirsttime   TIMESTAMP(6);
    DECLARE newlaststatus  INTEGER;
    DECLARE newlasttime    TIMESTAMP(6);
    DECLARE newduration    INTEGER;
    DECLARE newcontextid   NCHAR (36);
	DECLARE DONE INT DEFAULT FALSE;

    DECLARE cur_col1 CURSOR FOR   
    SELECT CONTEXTID, AUDITTIMESTAMP, STATUS,
	   AUDITTIMESTAMP, STATUS, DURATION
    FROM WMSERVICE
    WHERE CONTEXTID = NEW.CONTEXTID
    AND AUDITTIMESTAMP = NEW.AUDITTIMESTAMP;

	DECLARE CONTINUE HANDLER FOR NOT FOUND SET DONE = TRUE;

	OPEN cur_col1;
	read_loop: LOOP
	FETCH cur_col1 INTO newcontextid,
	   newfirsttime,
	   newfirststatus,
	   newlasttime,
	   newlaststatus,
	   newduration;
		IF DONE THEN 
			LEAVE read_loop;
		END IF;
           IF newcontextid IS NOT NULL THEN       
              SELECT  CONTEXTID,
					  FIRSTTIME,
					  FIRSTSTATUS,
					  LASTTIME,
					  LASTSTATUS
					 FROM WMSERVICE_MIN_MAX
					 WHERE CONTEXTID = newcontextid
					 INTO prcontextid, prfirsttime, prfirststatus, prlasttime, prlaststatus;

              IF prcontextid IS NULL THEN
                 INSERT INTO WMSERVICE_MIN_MAX
                        (CONTEXTID,
                         FIRSTTIME,
                         FIRSTSTATUS,
                         LASTTIME,
                         LASTSTATUS,
                         DURATION
                        )
                 VALUES (newcontextid,
                         newfirsttime,
                         newfirststatus,
                         newlasttime,
                         newlaststatus,
                         newduration
                        );
             ELSE 
				IF prfirsttime > newfirsttime THEN
				  UPDATE WMSERVICE_MIN_MAX
						SET FIRSTTIME = newfirsttime,
							FIRSTSTATUS = newfirststatus
						WHERE CONTEXTID = newcontextid;
				END IF;
	        IF prlasttime < newlasttime THEN
	          UPDATE WMSERVICE_MIN_MAX
                  SET LASTTIME = newlasttime,
		   DURATION = newduration
                  WHERE CONTEXTID = newcontextid;
            END IF;
                  -- wmn-1670 - catch race condition - update status only if different
		  IF prlaststatus<>newlaststatus THEN
		       UPDATE wmservice_min_max
		       SET laststatus = newlaststatus
		       WHERE contextid = newcontextid;	    	 
                END IF;
                -- wmn-1670 - catch race condition -activity/end status coming at same timestamp
		IF prlasttime = newfirsttime THEN
		 IF newlaststatus<>32776 THEN
	          UPDATE wmservice_min_max
	       	  SET lasttime = newlasttime,
		   laststatus = newlaststatus,
		   duration = newduration
	     	  WHERE contextid = newcontextid;
	      END IF;
         END IF;
		 END IF;
		END IF;
     END LOOP read_loop;
        CLOSE cur_col1;
END//

DELIMITER ;