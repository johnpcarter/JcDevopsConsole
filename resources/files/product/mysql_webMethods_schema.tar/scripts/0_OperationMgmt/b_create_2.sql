START TRANSACTION;

INSERT INTO OPERATION_MGR
            (OPERATION_CD,
             DEBUG_FL,
             EMAIL_RECIPIENTS
            )
     VALUES ('OPERATION MGMT',
             'N',
             '@@DEFAULT_EMAIL_RECIPIENT'
            );

INSERT INTO OPERATION_PARAMETER
            (OPERATION_CD,
             PARAMETER_CD,
             PARAMETER_DSCR,
             PARAMETER_VALUE
            )
     VALUES ('OPERATION MGMT',
             'MAILHOST',
             'Mail host of customer site',
             '@@MAILHOST'
            );


INSERT INTO OPERATION_MGR
            (OPERATION_CD,
             DEBUG_FL,
             EMAIL_RECIPIENTS
            )
     VALUES ('METADATAPKG',
             'Y',
             null
            );

INSERT INTO OPERATION_MGR
            (OPERATION_CD,
             DEBUG_FL,
             EMAIL_RECIPIENTS
            )
     VALUES ('DB MGMT',
             'Y',
             null
            );

INSERT INTO OPERATION_MGR
            (OPERATION_CD,
             DEBUG_FL,
             EMAIL_RECIPIENTS
            )
     VALUES ('DATA PURGE',
             'Y',
             '&1'
            );

INSERT INTO OPERATION_PARAMETER
            (OPERATION_CD,
             PARAMETER_CD,
             PARAMETER_DSCR,
             PARAMETER_VALUE
            )
     VALUES ('DATA PURGE',
             'COMMIT SIZE',
             'Number of records to commit in batch',
             '10000'
            );
            
INSERT INTO OPERATION_PARAMETER
            (OPERATION_CD,
             PARAMETER_CD,
             PARAMETER_DSCR,
             PARAMETER_VALUE
            )
     VALUES ('DATA PURGE',
             'LOG INTERVAL',
             'Interval of deleted records to log',
             '9999'
            );          

            
INSERT INTO OPERATION_PARAMETER
            (OPERATION_CD,
             PARAMETER_CD,
             PARAMETER_DSCR,
             PARAMETER_VALUE
            )
     VALUES ('DATA PURGE',
             'INCREMENT AMT',
             'Interval to increase delete batch size',
             '1000'
            );


INSERT INTO OPERATION_PARAMETER
            (OPERATION_CD,
             PARAMETER_GROUP_CD,
             PARAMETER_CD,
             PARAMETER_DSCR,
             PARAMETER_VALUE
            )
     VALUES ('DATA PURGE',
             'CONTROL DATE',
             'OPERATION_LOG',
             'Number of days of data to retain in table OPERATION_LOG',
             '14'
            );  

COMMIT;
