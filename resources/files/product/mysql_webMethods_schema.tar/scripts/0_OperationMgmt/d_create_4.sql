
DELIMITER //
CREATE PROCEDURE OPERATION_MGMT_GET_DEBUG_FL (
    INOUT p_l_debug_fl                         CHAR ,
    p_p_operation_cd                           VARCHAR (100))
    BEGIN

        /***************************************************************************
        ** Constant Variable declarations
        ****************************************************************************/
        DECLARE v_l_operation_cd                          VARCHAR(100);
        DECLARE v_l_procedure_name                        VARCHAR(200);
        DECLARE v_l_rtn_status_cd_debugfl_error           INT;
        DECLARE v_l_rtn_status_cd_error                   INT;

        /***************************************************************************
        ** Variable declarations
        ***************************************************************************/        

        DECLARE v_l_event_text                             VARCHAR(1000);
        DECLARE v_sql                                      VARCHAR(1000);

        /***************************************************************************
        ** Cursor declarations
        ***************************************************************************/        
        
        DECLARE c_get_debug_fl 
        CURSOR FOR 
        SELECT debug_fl
        FROM  OPERATION_MGR 
        WHERE operation_cd  = p_p_operation_cd;        
        
        /*******************************************************************************
        **                     Set default varaible values
        *******************************************************************************/
	SET v_l_operation_cd = "OPERATION MGMT";
        SET v_l_procedure_name = "GET_DEBUG_FL"; 
        SET v_l_rtn_status_cd_debugfl_error := 123457;
	SET v_l_rtn_status_cd_error = 1; 
        
        /*******************************************************************************
        **                     Executable Section
        *******************************************************************************/

        
        OPEN c_get_debug_fl; 
        
        FETCH c_get_debug_fl INTO p_l_debug_fl;
        
        CLOSE c_get_debug_fl;
        
        IF p_l_debug_fl IS NULL 
        THEN 
            SET p_l_debug_fl  = 'P'; 

            SET v_l_event_text = CONCAT('No OPERATION_MGR record found for '  ,  p_p_operation_cd);

        /***************************************************************************
        ** Call the sproc this way so dependency error is not created during install
        ****************************************************************************/
		
            SET v_sql = CONCAT('EXEC operation_mgmt_log_operation_event ''' ,  
                   v_l_operation_cd  , ''',''' ,  
                   v_l_procedure_name  , ''',' , 
                   CAST(v_l_rtn_status_cd_debugfl_error as CHAR) , ',''' , 
                   v_l_event_text , '''');

            SET @stmt_str = v_sql;
            PREPARE stmt FROM @stmt_str;
            EXECUTE stmt;
            DEALLOCATE PREPARE stmt;

        END IF;


    END//


DELIMITER ;



