
DELIMITER //
CREATE PROCEDURE OPERATION_MGMT_GET_PARAMETER (
    p_l_operation_cd                           VARCHAR (100),
    p_l_parameter_cd                           VARCHAR (100),
    p_l_parameter_value                        VARCHAR (200)) 
    BEGIN
        
        /***************************************************************************
        ** Cursor declarations
        ****************************************************************************/
        
        DECLARE c_get_parameter_value CURSOR FOR 
        SELECT parameter_value
        FROM  OPERATION_PARAMETER 
        WHERE     operation_cd  = p_l_operation_cd
         AND    parameter_cd  = p_l_parameter_cd;
        
        /*******************************************************************************
        **                     Executable Section
        *******************************************************************************/
        
        OPEN c_get_parameter_value; 
        
        FETCH NEXT FROM c_get_parameter_value INTO p_l_parameter_value;
        
        CLOSE c_get_parameter_value;

    END//

    DELIMITER ;


