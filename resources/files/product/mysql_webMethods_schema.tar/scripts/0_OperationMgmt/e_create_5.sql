
DELIMITER //
CREATE PROCEDURE OPERATION_MGMT_LOG_OPERATION_EVENT(
    p_l_operation_cd                           VARCHAR(100),
    p_l_procedure_name                         VARCHAR(200),
    p_l_rtn_status_cd                          INT,
    p_l_event_text                             VARCHAR(1000),
    p_l_operation_complete_fl                  VARCHAR(1) )
BEGIN

	/***************************************************************************
	** Constant Variable declarations
	****************************************************************************/
	DECLARE v_l_rtn_status_cd_no_error                INT;
	DECLARE v_l_rtn_status_cd_error                   INT;
	DECLARE v_l_rtn_status_cd_debugfl_error           INT;
	DECLARE v_l_default_error_code                    INT; 
	DECLARE v_crlf                                    VARCHAR (10);

	/***************************************************************************
	** Variable declarations
	***************************************************************************/

	DECLARE v_l_debug_fl                               CHAR(1); 
	DECLARE v_l_dbname                                 VARCHAR(30); 

	/***************************************************************************
	** Handler declarations
	***************************************************************************/
	DECLARE EXIT HANDLER FOR sqlexception BEGIN
	    SELECT 'SQLException encountered';
	END;

	/*******************************************************************************
	**                     Set defaults for variables Section
	*******************************************************************************/
	SET p_l_operation_complete_fl = 'N';

	SET v_l_rtn_status_cd_no_error                    = 0;
	SET v_l_rtn_status_cd_error                       = 1;
	SET v_l_rtn_status_cd_debugfl_error               = 123457;
	SET v_l_default_error_code                        = -20999;

	/*******************************************************************************
	**                     Executable Section
	*******************************************************************************/
	IF p_l_rtn_status_cd != v_l_rtn_status_cd_debugfl_error THEN
	    CALL OPERATION_MGMT_GET_DEBUG_FL(v_l_debug_fl,  p_l_operation_cd );
	ELSE
	    SET  v_l_debug_fl = 'N';
	END IF;

	IF (v_l_debug_fl = 'Y' OR p_l_rtn_status_cd <> v_l_rtn_status_cd_no_error ) AND v_l_debug_fl != 'P'
	THEN 
	    INSERT INTO  operation_log   
		  ( operation_cd , 
		    procedure_name , 
		    rtn_status_cd , 
		    event_text )  
	     VALUES         
		  ( p_l_operation_cd , 
		    p_l_procedure_name , 
		    p_l_rtn_status_cd , 
		    p_l_event_text ) ;

	END IF;

END//


DELIMITER ;