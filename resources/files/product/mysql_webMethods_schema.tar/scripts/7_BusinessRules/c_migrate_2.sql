CREATE TABLE rules_baseevent (
	id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
	`datetime` DATETIME NOT NULL,
	projectname VARCHAR(255) NOT NULL,
	sessionid VARCHAR(45),
	`host` VARCHAR(255) NOT NULL,
	`port` INT NOT NULL,
	displayName VARCHAR(255),
	userid VARCHAR(255)
);

CREATE TABLE rules_celltypes (
	id BIGINT NOT NULL PRIMARY KEY,
	celltype VARCHAR(45) NOT NULL
);

CREATE TABLE rules_dtchanges (
	id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    rmcsaved_id BIGINT,
    changetypes_id BIGINT,
    celltypes_id BIGINT,
	rownumber INT NOT NULL,
	columnname VARCHAR(255),
	parameterelement VARCHAR(255),
	oldvalue MEDIUMTEXT,
	newvalue MEDIUMTEXT,
	rowuuid VARCHAR(50)
);

CREATE TABLE rules_changetypes (
	id BIGINT NOT NULL PRIMARY KEY,
    changetype VARCHAR(45) NOT NULL
);

CREATE TABLE rules_projectdeployed (
	ID BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    BASEEVENT_ID BIGINT NOT NULL,
    PROJECTVERSION VARCHAR(255) NOT NULL,
    CORRELATION_ID VARCHAR(255),
    PROJECTCREATORAPP VARCHAR(255),
    DEPLOYEDWITH VARCHAR(255),
    DEPLOYEDBY VARCHAR(255)
);

CREATE TABLE rules_projectundeployed (
	id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    baseevent_id BIGINT NOT NULL,
    projectversion VARCHAR(255) NOT NULL,
    CORRELATION_ID VARCHAR(255)
);

CREATE TABLE rules_projectimported (
	id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    baseevent_id BIGINT NOT NULL,
    decisionentities TEXT,
    projectversion VARCHAR(255) NOT NULL,
    CORRELATION_ID VARCHAR(255)
);
	
CREATE TABLE rules_projectexported (
	id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    baseevent_id BIGINT NOT NULL,
	decisionentities TEXT,
    projectversion VARCHAR(255) NOT NULL
);

CREATE TABLE rules_rmcsaved (
	id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    baseevent_id BIGINT,
    decisionentityname VARCHAR(255) NOT NULL,
    CORRELATION_ID VARCHAR(255)
);

CREATE TABLE rules_rmchotdeploymentstarted (
	id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    baseevent_id BIGINT,
    CORRELATION_ID VARCHAR(255),
    ishost VARCHAR(255) NOT NULL,
    `port` INTEGER NOT NULL,
    projectversion VARCHAR(255) NOT NULL
);

CREATE TABLE rules_erchanges (
	id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    rmcsaved_id BIGINT,
    changetypes_id BIGINT,
    rownumber INTEGER NOT NULL,
    resultname VARCHAR(255),
    oldvalue MEDIUMTEXT,
    newvalue MEDIUMTEXT,
    rowuuid VARCHAR(50)
);

CREATE TABLE rules_projectdeleted (
	id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    baseevent_id BIGINT NOT NULL,
    projectversion VARCHAR(255) NOT NULL
);

ALTER TABLE rules_dtchanges
	ADD CONSTRAINT rules_dtc_celltypes_ref
    FOREIGN KEY	(celltypes_id)
    REFERENCES rules_celltypes (id);

ALTER TABLE rules_dtchanges
	ADD CONSTRAINT rules_dtc_changetypes_ref
    FOREIGN KEY	(changetypes_id)
    REFERENCES rules_changetypes (id);

ALTER TABLE rules_dtchanges
	ADD CONSTRAINT rules_dtc_rmcsaved_ref
    FOREIGN KEY	(rmcsaved_id)
    REFERENCES rules_rmcsaved (id);

ALTER TABLE rules_erchanges
	ADD CONSTRAINT rules_erc_rmcsaved_ref
    FOREIGN KEY	(rmcsaved_id)
    REFERENCES rules_rmcsaved (id);

ALTER TABLE rules_erchanges
	ADD CONSTRAINT rules_erc_changetypes_ref
    FOREIGN KEY	(changetypes_id)
    REFERENCES rules_changetypes (id);
	
ALTER TABLE rules_projectdeployed
	ADD CONSTRAINT rules_pd_baseevent_ref
    FOREIGN KEY	(baseevent_id)
    REFERENCES rules_baseevent (id);
	
ALTER TABLE rules_projectundeployed
	ADD CONSTRAINT rules_pu_baseevent_ref
    FOREIGN KEY	(baseevent_id)
    REFERENCES rules_baseevent (id);
	
ALTER TABLE rules_projectimported
	ADD CONSTRAINT rules_pi_baseevent_ref
    FOREIGN KEY	(baseevent_id)
    REFERENCES rules_baseevent (id);
	
ALTER TABLE rules_projectexported
	ADD CONSTRAINT rules_pe_baseevent_ref
    FOREIGN KEY	(baseevent_id)
    REFERENCES rules_baseevent (id);

ALTER TABLE rules_rmcsaved
	ADD CONSTRAINT rules_rmcs_baseevent_ref
    FOREIGN KEY	(baseevent_id)
    REFERENCES rules_baseevent (id);

ALTER TABLE rules_rmchotdeploymentstarted
	ADD CONSTRAINT rules_rmchds_baseevent_ref
    FOREIGN KEY (baseevent_id)
    REFERENCES rules_baseevent (id);

ALTER TABLE rules_projectdeleted
	ADD CONSTRAINT rules_pdel_baseevent_ref
    FOREIGN KEY	(baseevent_id)
    REFERENCES rules_baseevent (id);
	
INSERT INTO rules_changetypes VALUES (1, 'ADDED');
INSERT INTO rules_changetypes VALUES (2, 'DELETED');
INSERT INTO rules_changetypes VALUES (3, 'CHANGED');

INSERT INTO rules_celltypes VALUES (1, 'CONDITIONCELL');
INSERT INTO rules_celltypes VALUES (2, 'RESULTCELL');