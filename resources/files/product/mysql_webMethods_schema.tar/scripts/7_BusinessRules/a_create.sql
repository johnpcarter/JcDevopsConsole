CREATE TABLE BusinessRulesTargetRuntimes (
	serverId varchar(200) NOT NULL, 
	lastUpdateTimestamp DATETIME NOT NULL, 
	isOnline SMALLINT DEFAULT 0 NOT NULL,
	isBlackListed SMALLINT DEFAULT 0 NOT NULL 
);

CREATE TABLE BusinessRulesProjectLog (
	serverId varchar(200) NOT NULL, 
	projectName varchar(100) NOT NULL, 
	projectVersion varchar(100) NOT NULL, 
	userName varchar(200) NOT NULL, 
	timestamp  DATETIME NOT NULL, 
	type varchar(50) NOT NULL
);
