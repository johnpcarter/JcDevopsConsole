START TRANSACTION;

INSERT INTO operation_parameter
            (operation_cd,
             parameter_group_cd,
             parameter_cd,
             parameter_dscr,
             parameter_value
            )
     VALUES ('DATA PURGE',
             'CONTROL DATE',
             'BAM_DIM_TMP',
             'Number of days of data to retain in table BAM_DIM_TMP',
             '90'
            );

INSERT INTO operation_parameter
            (operation_cd,
             parameter_group_cd,
             parameter_cd,
             parameter_dscr,
             parameter_value
            )
     VALUES ('DATA PURGE',
             'CONTROL DATE',
             'BAM_DIM_TMP_ATTR',
             'Number of days of data to retain in table BAM_DIM_TMP_ATTR',
             '90'
            );
            
INSERT INTO operation_parameter
            (operation_cd,
             parameter_group_cd,
             parameter_cd,
             parameter_dscr,
             parameter_value
            )
     VALUES ('DATA PURGE',
             'CONTROL DATE',
             'BAM_DIM_JOIN_TMP',
             'Number of days of data to retain in table BAM_DIM_JOIN_TMP',
             '90'
            );

INSERT INTO operation_parameter
            (operation_cd,
             parameter_group_cd,
             parameter_cd,
             parameter_dscr,
             parameter_value
            )
     VALUES ('DATA PURGE',
             'CONTROL DATE',
             'BAM_ALG_MONITOR',
             'Number of days of data to retain in table BAM_ALG_MONITOR',
             '90'
            );

INSERT INTO operation_parameter
            (operation_cd,
             parameter_group_cd,
             parameter_cd,
             parameter_dscr,
             parameter_value
            )
     VALUES ('DATA PURGE',
             'CONTROL DATE',
             'BAM_RULE_VIOLATION',
             'Number of days of data to retain in table BAM_RULE_VIOLATION',
             '90'
            );

INSERT INTO operation_parameter
            (operation_cd,
             parameter_group_cd,
             parameter_cd,
             parameter_dscr,
             parameter_value
            )
     VALUES ('DATA PURGE',
             'CONTROL DATE',
             'BAM_RULE_COMPLIANCE_FACT',
             'Number of days of data to retain in table BAM_RULE_COMPLIANCE_FACT',
             '90'
            );
            
COMMIT;