
INSERT INTO component_event
            (component_cd,
             component_desc,
             component_event,
             component_level
            )
     VALUES ('OPT_AE_ANL',
             'Optimize Analytic Engine Analysis Component',
             'INSTALL',
             '85'
            );

commit;
