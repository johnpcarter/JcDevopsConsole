
INSERT INTO component_event
            (component_cd,
             component_desc,
             component_event,
             component_level
            )
     VALUES ('OPT_AE_PTR',
             'Optimize Analytic Engine Process Tracker Component',
             'INSTALL',
             '50'
            );

commit;
