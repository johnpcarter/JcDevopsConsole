-- ***********************************************************************
-- 
--  Warning: TAKE A BACKUP OF YOUR DATABASE BEFORE RUNNING THIS SCRIPT!
-- 
-- ***********************************************************************

ALTER TABLE IS_OAUTH_SCOPE ADD SCOPE_DESCRIPTION VARCHAR(2048);
