-- ***********************************************************************
-- 
--  Warning: TAKE A BACKUP OF YOUR DATABASE BEFORE RUNNING THIS SCRIPT!
-- 
-- ***********************************************************************

SET SESSION sql_mode = "PIPES_AS_CONCAT,IGNORE_SPACE,NO_KEY_OPTIONS,NO_TABLE_OPTIONS,NO_FIELD_OPTIONS";

SET @sql = (
	SELECT IF(
    (SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA=database() and 
								TABLE_NAME='IS_USER_TASKS' and column_name='LAST_UPDATED'
    ) > 0,
    "SELECT 0",
    "ALTER TABLE IS_USER_TASKS ADD LAST_UPDATED DECIMAL(20,0)"
));

PREPARE stmt FROM @sql;
EXECUTE stmt;
