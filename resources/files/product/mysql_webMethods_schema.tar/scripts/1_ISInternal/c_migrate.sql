-- ***********************************************************************
-- 
--  Warning: TAKE A BACKUP OF YOUR DATABASE BEFORE RUNNING THIS SCRIPT!
-- 
-- ***********************************************************************

ALTER TABLE IS_CERTIFICATE_MAP 
CHANGE COLUMN CERT_EXPIRATION CERT_EXPIRATION DATETIME;
