-- ***********************************************************************
-- 
--  Warning: TAKE A BACKUP OF YOUR DATABASE BEFORE RUNNING THIS SCRIPT!
-- 
-- ***********************************************************************
ALTER TABLE IS_OAUTH_CLIENTS ADD ALLOWED_GRANTS SMALLINT; 
