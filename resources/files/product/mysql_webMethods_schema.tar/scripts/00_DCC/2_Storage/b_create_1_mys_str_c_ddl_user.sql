-- create the user if not exists and grant all permissions
SET SESSION sql_mode = "PIPES_AS_CONCAT,IGNORE_SPACE,NO_KEY_OPTIONS,NO_TABLE_OPTIONS,NO_FIELD_OPTIONS";
SET @dbname='&dbname', @username='&user', @password='&password';

SET @query1 = CONCAT('CREATE USER "',@username,'"@"%" IDENTIFIED BY "',@password,'" ');
PREPARE stmt FROM @query1; 
EXECUTE stmt; 
DEALLOCATE PREPARE stmt;

SET @query1 = CONCAT('GRANT ALL PRIVILEGES ON *.* TO "',@username,'"@"%" IDENTIFIED BY "',@password,'" ');
PREPARE stmt FROM @query1; 
EXECUTE stmt; 
DEALLOCATE PREPARE stmt;

SET @query1 = CONCAT('GRANT ALL PRIVILEGES ON *.* TO "',@username,'"@"localhost" IDENTIFIED BY "',@password,'" ');
PREPARE stmt FROM @query1; 
EXECUTE stmt; 
DEALLOCATE PREPARE stmt;

FLUSH PRIVILEGES;