  -- Create database if not exists

SET @query1 = CONCAT('CREATE DATABASE IF NOT EXISTS wm ');
PREPARE stmt FROM @query1; 
EXECUTE stmt; 
DEALLOCATE PREPARE stmt;